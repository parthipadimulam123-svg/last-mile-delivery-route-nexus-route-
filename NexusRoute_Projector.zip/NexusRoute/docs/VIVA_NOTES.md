# NexusRoute 3.0 — Presentation & Viva Notes

## 30-second pitch
> "A drone has limited payload and many parcels, each with profit, weight and a deadline. I solve it in three
> stages: **(1)** an exact **0/1 knapsack by dynamic programming** picks the best parcels; **(2)** a routing stage
> orders them using greedy → **2-opt/Or-opt → simulated annealing**, benchmarked against the **exact Held-Karp**
> optimum; **(3)** because the knapsack ignores deadlines, a **deadline-aware repair** swaps parcels so the profit
> that actually arrives on time goes up. Over 100 random cities it raised average realised profit from **$234 to
> $321** and was never worse than the original. Everything is verified against brute force and shown in a live 3D
> dashboard."

## Suggested demo flow (3 minutes)
1. `python run.py --selftest` → "every algorithm is checked against brute force."
2. `python run.py --seed 42` → point at: DP table + white backtrack path, PAPER $ bars (greedy ≤ DP ≤ LP),
   REALISED $ bars (V1 → +ROUTE → +FIX), purple/white rings in 3D (parcels the repair swapped), timeline.
3. Press `N` for a new city, drag the sliders, press `EXECUTE`.
4. `python run.py --benchmark 100` → show the chart.

## Likely questions and answers

**Why dynamic programming and not greedy?**
Greedy-by-ratio is fast but can be sub-optimal (it never revisits a decision). DP examines all capacity levels
and is *exactly* optimal. The benchmark shows DP ≥ greedy in 100 % of cities and strictly better in many.

**What is the time complexity of the knapsack?**
O(n·W) time and memory. It is *pseudo-polynomial*: polynomial in the numeric value W, not in its bit-length, so the
problem is still NP-hard in general. Our W is only 60–150 kg, so it takes ≈ 0.16 ms.

**How do you know your DP is correct?**
It is compared with brute force on 150 random instances (identical optimum every time) and must satisfy
`greedy ≤ DP ≤ LP-relaxation bound` on 300 instances.

**What is the LP / fractional upper bound?**
If parcels could be split, taking them by best profit/weight is optimal; this value can never be beaten by any
integer solution, so it brackets the true optimum from above.

**Why is nearest-neighbour not enough?**
It is myopic: it always picks the closest parcel and never looks ahead, so it creates crossing edges and
late arrivals. It is kept as the *baseline* (the original code).

**What are 2-opt and Or-opt?**
2-opt reverses a segment of the tour (removes crossings). Or-opt moves a block of 1–3 parcels to another position.
Repeating them gives a local optimum.

**Why simulated annealing after local search?**
Local search gets stuck in local optima. SA accepts worse routes with probability e^(−Δ/T) while the temperature
T cools, so it explores first and refines later. It returns the best route seen, so it can never be worse than
its starting point.

**What is Held-Karp and why use it?**
An exact bitmask DP for the travelling-salesman tour in O(2ᵐ·m²). It gives the true shortest tour for ≤ 13 stops,
so we can *measure* how far our heuristics are from optimal (on average 4.9 %). It ignores deadlines, therefore
the best deadline-aware route may be slightly longer — extra distance buys punctuality.

**What problem did you find in the original?**
The knapsack maximises profit but ignores location and deadlines, so a parcel that is selected may be delivered
late and earn nothing. In the original, often fewer than half the selected parcels arrived on time.

**How does Stage 3 fix it? Is it optimal?**
Hill-climbing on the set of loaded parcels with ADD/DROP/SWAP moves, scoring each candidate by the profit
delivered on time. It is a heuristic (not proven optimal) but guaranteed not worse than the original plan —
a property checked in the self-test and in 100/100 benchmark cities.

**Why "realised profit" instead of profit?**
Because the business only earns money for parcels delivered before their deadline.

**What are the limitations?**
Single drone, single trip, no service time/battery/wind; Held-Karp limited to ~13 stops; Stage 3 is heuristic.

**How would you extend it?**
Multiple drones (vehicle routing), battery constraints, time windows with service times, dynamic re-planning,
a web API on top of the backend package.

**Is it reproducible?**
Yes. Every run prints its random seed; the same seed gives identical results (unit-tested).

## Glossary
* **0/1 knapsack** — each item is taken or not; maximise value under a weight limit.
* **Heuristic** — fast method without an optimality proof. **Metaheuristic** — general strategy (e.g. SA).
* **Realised profit** — profit of parcels delivered on time.
* **Optimality gap** — how much worse than the optimum, in %.
* **Blitting** — redrawing only the moving parts of the screen (why the live animation is smooth).
