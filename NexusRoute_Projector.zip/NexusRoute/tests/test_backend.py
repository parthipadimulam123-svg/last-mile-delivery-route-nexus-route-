"""Unit tests for the backend (no GUI needed).   Run:  python -m unittest discover -s tests -v"""
import itertools
import os
import random
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from nexusroute.backend import (Config, build_flight, fractional_upper_bound, generate_parcels,
                                greedy_by_ratio, held_karp, knapsack_dp, solve)
from nexusroute.backend.solver import ROUTE_LS, ROUTE_NN, ROUTE_SA


def brute_force_knapsack(profits, weights, W):
    best = 0
    n = len(profits)
    for mask in range(1 << n):
        w = sum(weights[i] for i in range(n) if mask >> i & 1)
        if w <= W:
            best = max(best, sum(profits[i] for i in range(n) if mask >> i & 1))
    return best


class KnapsackTests(unittest.TestCase):
    def test_matches_brute_force(self):
        rng = random.Random(1)
        for _ in range(80):
            n, W = rng.randint(1, 11), rng.randint(5, 50)
            pr = [rng.randint(1, 90) for _ in range(n)]
            wt = [rng.randint(1, 18) for _ in range(n)]
            r = knapsack_dp(pr, wt, W)
            self.assertEqual(r.profit, brute_force_knapsack(pr, wt, W))
            self.assertEqual(sum(pr[i] for i in r.selected), r.profit)
            self.assertLessEqual(sum(wt[i] for i in r.selected), W)

    def test_bounds(self):
        rng = random.Random(2)
        for _ in range(100):
            n, W = rng.randint(5, 30), rng.randint(20, 80)
            pr = [rng.randint(1, 100) for _ in range(n)]
            wt = [rng.randint(1, 20) for _ in range(n)]
            dp = knapsack_dp(pr, wt, W).profit
            self.assertLessEqual(greedy_by_ratio(pr, wt, W)[0], dp)
            self.assertLessEqual(dp, fractional_upper_bound(pr, wt, W) + 1e-9)

    def test_zero_capacity(self):
        self.assertEqual(knapsack_dp([5, 6], [3, 4], 0).profit, 0)


class RoutingTests(unittest.TestCase):
    def test_held_karp_matches_permutations(self):
        rng = random.Random(3)
        for _ in range(15):
            m = rng.randint(2, 6)
            pts = np.vstack([np.zeros(3)] + [np.array([rng.uniform(-40, 40) for _ in range(3)]) for _ in range(m)])
            D = np.linalg.norm(pts[:, None] - pts[None], axis=2)
            brute = min(D[0, p[0] + 1] + sum(D[p[i] + 1, p[i + 1] + 1] for i in range(m - 1)) + D[p[-1] + 1, 0]
                        for p in itertools.permutations(range(m)))
            self.assertAlmostEqual(held_karp(D)[0], brute, places=6)


class SolverTests(unittest.TestCase):
    def setUp(self):
        self.cfg = Config(seed=123, sa_iters=2000)
        self.sol = solve(self.cfg, generate_parcels(self.cfg))

    def test_reproducible(self):
        again = solve(Config(seed=123, sa_iters=2000), generate_parcels(Config(seed=123)))
        self.assertEqual(self.sol.best.order, again.best.order)

    def test_capacity(self):
        self.assertLessEqual(self.sol.final_weight, self.cfg.capacity)

    def test_never_worse_than_v1(self):
        self.assertGreaterEqual(self.sol.best.realised_profit, self.sol.baseline.realised_profit)

    def test_route_ordering(self):
        r = self.sol.routes
        self.assertLessEqual(r[ROUTE_LS].cost, r[ROUTE_NN].cost + 1e-6)
        self.assertLessEqual(r[ROUTE_SA].cost, r[ROUTE_LS].cost + 1e-6)

    def test_flight_is_consistent(self):
        f = build_flight(self.sol, 10, 3)
        self.assertEqual(len(f.pts), len(f.t))
        self.assertEqual(int(f.delivered[-1]), len(self.sol.best.stops))
        self.assertEqual(int(f.payload[-1]), 0)
        self.assertTrue(np.allclose(f.pts[-1], 0))

    def test_tiny_capacity(self):
        cfg = Config(n_parcels=10, capacity=1, seed=5)
        sol = solve(cfg, generate_parcels(cfg))
        self.assertEqual(len(sol.selected), 0)
        build_flight(sol, 10, 3)


if __name__ == "__main__":
    unittest.main()
