# NexusRoute 3.0 — Python Edition
### Advanced 3D Last-Mile Drone Delivery Optimizer

A delivery drone must decide **which parcels to load** (limited payload) and **in what order to fly them**
(each parcel has a deadline) so that the profit that *really arrives on time* is as high as possible.

This project converts the original JavaScript/Three.js prototype (`original_html/`) into a complete Python
application, **adds four new algorithms, an automatic test-suite, a Monte-Carlo benchmark** and a live
**dark neon 3D dashboard**.

![dashboard](assets/dashboard_preview.png)

---

## 1. Quick start

You need **Python 3.9 or newer**.

| System | What to do |
|---|---|
| **Windows** | double-click **`run_windows.bat`** (creates a virtual environment, installs everything, starts the dashboard) |
| **macOS / Linux** | `./run_mac_linux.sh` |
| **Manual** | `pip install -r requirements.txt` then `python run.py` |

Other useful commands

```bash
python run.py --seed 42                 # reproducible city (the seed is always printed)
python run.py -n 40 -c 80               # 40 parcels, 80 kg payload
python run.py --no-gui                  # console report only (no window)
python run.py --selftest                # 11 correctness tests vs brute force
python run.py --benchmark 100           # Monte-Carlo study over 100 cities + chart
python run.py --save-png out.png        # 1920x1080 dashboard snapshot
python run.py --save-gif flight.gif     # animated flight (takes ~1 min)
python run.py --export results          # report.json + route.csv
python run.py --no-repair               # run ONLY the original pipeline (for comparison)
python -m unittest discover -s tests -v # unit tests
```

### Dashboard controls
| Key / button | Action |
|---|---|
| **EXECUTE OPTIMIZATION** / `E` | apply the two sliders (capacity, #parcels), re-solve, replay the flight |
| **NEW SEED** / `N` | brand-new random city |
| **ROTATE** / `T` | toggle automatic camera orbit (you can also drag with the mouse) |
| `SPACE` | pause / resume the flight |
| `B` | show / hide the original (v1) route |
| `F` | full-screen |

---

## 2. Project structure

```
NexusRoute/
├── run.py                      entry point
├── run_windows.bat / run_mac_linux.sh   one-click launchers
├── requirements.txt            numpy, matplotlib, Pillow
├── nexusroute/
│   ├── cli.py                  command-line interface
│   ├── selftest.py             11 brute-force correctness tests
│   ├── benchmark.py            Monte-Carlo benchmark + 6-panel chart
│   ├── backend/                ← ALL ALGORITHMS (needs only NumPy, no GUI)
│   │   ├── models.py           Config, Parcel, random city generator
│   │   ├── knapsack.py         STAGE 1  0/1 Knapsack DP, greedy-ratio, LP bound
│   │   ├── routing.py          STAGE 2  greedy NN, 2-opt/Or-opt, Simulated Annealing, Held-Karp
│   │   ├── solver.py           STAGE 3  deadline-aware repair + full pipeline `solve()`
│   │   ├── flight.py           pre-computed drone flight timeline
│   │   ├── report.py           terminal report, JSON/CSV export
│   │   └── term.py             ANSI colours
│   └── frontend/               ← VISUALISATION (matplotlib)
│       ├── theme.py            dark neon palette, glow effects
│       └── dashboard.py        3D scene, KPI cards, console, DP heat-map, charts, widgets, GIF/PNG export
├── tests/test_backend.py       unit tests
├── docs/VIVA_NOTES.md          explanations + likely viva questions with answers
├── assets/                     screenshot, benchmark chart, demo GIF
└── original_html/              the original Three.js version, for comparison
```

The backend knows nothing about graphics, so it can be tested, benchmarked or reused (e.g. behind a web API) on its own.

---

## 3. How it works

| Stage | Algorithm | Purpose | Complexity |
|---|---|---|---|
| **1** | **0/1 Knapsack — Dynamic Programming** | choose the max-profit parcels that fit the payload (provably optimal) | O(n·W) |
| 1b | Greedy-by-ratio and the **fractional (LP) upper bound** | prove DP is optimal: `greedy ≤ DP ≤ LP bound` | O(n log n) |
| **2** | **Greedy deadline-aware nearest neighbour** (the original heuristic) | baseline route | O(m²) |
| 2b | **2-opt + Or-opt local search** | remove crossings / relocate blocks | O(m³) per pass |
| 2c | **Simulated Annealing** | escape local optima | O(iterations · m) |
| 2d | **Held-Karp exact DP** | shortest possible tour → measures how good the heuristics are | O(2ᵐ·m²) |
| **3** | **Deadline-aware repair** (hill-climbing on the *selection*: ADD / DROP / SWAP) | fixes the blind spot of the knapsack, see below | O(sweeps · n·m · route cost) |

`n` = parcels, `W` = capacity, `m` = parcels actually loaded (≈ 6–15).

**Knapsack recurrence**

```
dp[i][w] = dp[i-1][w]                                   if weight_i > w
         = max( dp[i-1][w],  dp[i-1][w-weight_i] + profit_i )   otherwise
```

**Route cost that the optimiser minimises**

```
cost = total_distance + late_penalty × (#late parcels) + total_lateness
```

**Why Stage 3 exists (the key improvement).** The knapsack maximises *paper* profit and knows nothing about
*where* a parcel is or *when* it is due, and a late parcel earns nothing. So the DP-optimal load often has a low
*realised* profit. Stage 3 starts from the DP optimum and keeps applying the best ADD / DROP / SWAP move
(each candidate is routed and scored on the profit that arrives on time) until nothing improves. Because it only
accepts strict improvements, **it can never be worse than the original pipeline** (checked by the self-test).

---

## 4. What is new compared with the original HTML

| | Original (JavaScript) | This version |
|---|---|---|
| Parcel selection | Knapsack DP | Knapsack DP **+ proof via LP bound + deadline-aware repair** |
| Routing | greedy nearest neighbour | greedy → **2-opt/Or-opt → Simulated Annealing**, benchmarked vs **exact Held-Karp** |
| Metrics | profit, weight, on-time | + **realised profit**, route length vs optimum, speed-ups vs the original |
| Verification | none | **11 self-tests vs brute force** + unit tests |
| Evidence | none | **Monte-Carlo benchmark** with charts |
| Reproducibility | random every time | **seeded**, seed printed and shown on screen |
| UI | 3D view + console | 3D view, DP-table heat-map, comparison charts, delivery timeline, telemetry (time/altitude/payload), sliders |
| Output | screen only | PNG, GIF, JSON, CSV, terminal report |

---

## 5. Measured results

`python run.py --benchmark 100 --seed 5000` (100 random cities, 30 parcels, 60 kg):

| Metric | Result |
|---|---|
| DP vs greedy-by-ratio (paper profit) | DP ≥ greedy in **100 %** of cities (avg +1.0 %, up to +7.2 %); never exceeded the LP bound |
| **Average realised (on-time) profit** | original v1 **$234** → NexusRoute 3.0 **$321** |
| NexusRoute vs original | **never worse (100 %)**, strictly better in **85 %** of cities |
| On-time deliveries | 32 % → 47 % |
| Route length vs exact optimum (Held-Karp) | on average only **4.9 %** longer (the extra distance buys punctuality) |
| Speed | DP table in ≈ 0.16 ms; the whole pipeline ≈ 70 ms per city |

![benchmark](assets/benchmark_report.png)

---

## 6. Honest limitations (good to mention!)

* One drone, one trip, zero service time at each stop.
* Stage 3 and the routing metaheuristics are heuristics — only the knapsack (paper profit) and Held-Karp
  (pure distance) are provably optimal. Held-Karp ignores deadlines, so it is a *benchmark*, not a target.
* Held-Karp is skipped automatically when more than 13 parcels are loaded (2ᵐ growth).

Possible future work: several drones / multiple trips (vehicle routing), battery model, wind, live traffic data,
a web front-end on top of the existing backend.

---

## 7. Troubleshooting

| Problem | Fix |
|---|---|
| `No module named tkinter` (Linux) | `sudo apt install python3-tk` |
| Window does not open / wrong GUI backend | set `MPLBACKEND=TkAgg` (or `QtAgg`) before running |
| Animation feels slow | close other heavy programs; shrink the window or press `F` only on a fast PC; use `--frames-per-leg 20` |
| Characters look wrong in the terminal | use Windows Terminal / any UTF-8 terminal |
| `pip` not found | use `python -m pip install -r requirements.txt` |
