@echo off
REM ---- NexusRoute 3.0 : one-click launcher for Windows ----
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed or not on PATH. Install Python 3.9+ from https://www.python.org/downloads/
  echo ^(tick "Add python.exe to PATH" in the installer^)
  pause
  exit /b 1
)
if not exist ".venv" (
  echo [setup] creating virtual environment ...
  python -m venv .venv
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
python run.py %*
pause
