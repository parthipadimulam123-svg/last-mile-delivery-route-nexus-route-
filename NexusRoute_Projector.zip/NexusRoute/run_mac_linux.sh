#!/usr/bin/env bash
# ---- NexusRoute 3.0 : one-click launcher for macOS / Linux ----
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then echo "Please install Python 3.9+"; exit 1; fi
if [ ! -d ".venv" ]; then
  echo "[setup] creating virtual environment ..."
  python3 -m venv .venv
  source .venv/bin/activate
  python -m pip install --upgrade pip
  pip install -r requirements.txt
else
  source .venv/bin/activate
fi
python run.py "$@"
