"""NexusRoute 3.0 - Advanced 3D last-mile drone delivery optimizer (Python edition)."""
__version__ = "3.0.0"
