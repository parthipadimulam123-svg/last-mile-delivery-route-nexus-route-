"""Monte-Carlo benchmark over many random cities + dark-mode report chart.

For every random city we compare
    * DP vs greedy-by-ratio (paper profit)                     -> proves the knapsack stage
    * ORIGINAL v1 pipeline (DP + greedy NN)  vs  NexusRoute 3.0 -> realised (on-time) profit
    * best route length vs the Held-Karp exact optimum          -> routing quality
    * DP runtime for growing n                                  -> O(n*W) scaling
"""
from __future__ import annotations

import random
import time
from pathlib import Path

import numpy as np

from .backend.knapsack import knapsack_dp
from .backend.models import Config, generate_parcels
from .backend.report import banner
from .backend.solver import solve
from .backend.term import bold, cyan, dim, green


def run_benchmark(trials: int, base_cfg: Config, out_png: str) -> int:
    banner()
    print(bold(cyan(f"[ BENCHMARK ]  {trials} random cities  (n={base_cfg.n_parcels}, W={base_cfg.capacity})\n")))
    keys = ("dp", "greedy", "lp", "real_v1", "real_route", "real_final", "ot_v1", "ot_final",
            "d_best", "d_hk", "t_dp", "t_total")
    rec = {k: [] for k in keys}
    t_start = time.perf_counter()
    for t in range(trials):
        cfg = Config(**{**base_cfg.__dict__, "seed": (base_cfg.seed or 0) + t,
                        "sa_iters": min(base_cfg.sa_iters, 4000)})
        sol = solve(cfg, generate_parcels(cfg))
        rec["dp"].append(sol.knap.profit)
        rec["greedy"].append(sol.greedy_profit)
        rec["lp"].append(sol.lp_bound)
        rec["real_v1"].append(sol.baseline.realised_profit)
        rec["real_route"].append(sol.dp_suite.best.realised_profit)
        rec["real_final"].append(sol.best.realised_profit)
        rec["ot_v1"].append(sol.baseline.efficiency)
        rec["ot_final"].append(sol.best.efficiency)
        rec["d_best"].append(sol.best.distance)
        rec["d_hk"].append(sol.hk_distance if sol.hk_distance is not None else np.nan)
        rec["t_dp"].append(sol.knap.runtime_ms)
        rec["t_total"].append(sol.total_ms)
        if (t + 1) % max(1, trials // 10) == 0:
            print(dim(f"  ... {t + 1}/{trials}"))
    R = {k: np.array(v, dtype=float) for k, v in rec.items()}

    gain = 100 * (R["dp"] - R["greedy"]) / np.maximum(R["greedy"], 1)
    real_gain = 100 * (R["real_final"] - R["real_v1"]) / np.maximum(R["real_v1"], 1)
    ot_gain = R["ot_final"] - R["ot_v1"]
    gap = 100 * (R["d_best"] - R["d_hk"]) / R["d_hk"]
    gg = gap[~np.isnan(gap)]

    print()
    print(bold("  METRIC".ljust(52) + "MEAN".rjust(10) + "STD".rjust(9) + "MIN".rjust(9) + "MAX".rjust(9)))
    rows = [
        ("DP paper-profit gain over greedy-by-ratio (%)", gain),
        ("Realised profit - original v1 pipeline ($)", R["real_v1"]),
        ("Realised profit - NexusRoute 3.0 ($)", R["real_final"]),
        ("Realised profit improvement (%)", real_gain),
        ("On-time rate - original v1 (%)", R["ot_v1"]),
        ("On-time rate - NexusRoute 3.0 (%)", R["ot_final"]),
        ("Route length above Held-Karp optimum (%)", gg if gg.size else np.array([0.0])),
        ("DP runtime (ms)", R["t_dp"]),
        ("Whole pipeline runtime (ms)", R["t_total"]),
    ]
    for name, arr in rows:
        print(f"  {name:<50}{np.mean(arr):>10.2f}{np.std(arr):>9.2f}{np.min(arr):>9.2f}{np.max(arr):>9.2f}")
    print()
    dp_ok = bool(np.all(R["dp"] <= R["lp"] + 1e-9))
    dp_vs_greedy = 100 * np.mean(R["dp"] >= R["greedy"])
    nx_ge = 100 * np.mean(R["real_final"] >= R["real_v1"])
    nx_gt = 100 * np.mean(R["real_final"] > R["real_v1"])
    print(f"  DP never exceeded the LP upper bound : {green(str(dp_ok))}")
    print(f"  DP >= greedy-by-ratio in             : {green(f'{dp_vs_greedy:.0f}%')} of cities")
    print(f"  NexusRoute realised profit >= v1 in  : {green(f'{nx_ge:.0f}%')} of cities (strictly better in {nx_gt:.0f}%)")
    print(dim(f"  total benchmark time {time.perf_counter() - t_start:.1f} s\n"))

    # ---- scaling experiment: DP runtime vs n --------------------------------------------------
    ns = [10, 25, 50, 100, 200, 400]
    rr = random.Random(1)
    scale = []
    for n in ns:
        pr = [rr.randint(15, 104) for _ in range(n)]
        wt = [rr.randint(4, 15) for _ in range(n)]
        t0 = time.perf_counter()
        knapsack_dp(pr, wt, 200)
        scale.append((time.perf_counter() - t0) * 1e3)

    # ---- dark benchmark figure ----------------------------------------------------------------
    import matplotlib.pyplot as plt
    from .frontend.theme import BG, CYAN, GREEN, MUTED, PANEL, PINK, PURPLE, TEXT, YELLOW, _glow

    plt.rcParams.update({"font.family": "monospace", "text.color": TEXT, "text.parse_math": False})
    fig, axs = plt.subplots(2, 3, figsize=(17, 8.8), facecolor=BG)
    fig.suptitle("NEXUSROUTE 3.0  //  BENCHMARK REPORT", color=CYAN, fontsize=18, fontweight="bold",
                 path_effects=_glow(6, CYAN, 0.2), y=0.975)
    fig.text(0.5, 0.927, f"{trials} random cities   ·   {base_cfg.n_parcels} parcels   ·   capacity {base_cfg.capacity} kg",
             ha="center", color=MUTED, fontsize=9)
    for ax in axs.flat:
        ax.set_facecolor(PANEL)
        for sp in ax.spines.values():
            sp.set_color((0, 0.95, 1, 0.35))
        ax.tick_params(colors=MUTED, labelsize=8)
        ax.grid(color=CYAN, alpha=0.07)
    bins = min(25, max(5, trials // 4))

    ax = axs[0, 0]
    ax.set_title("1  PROFIT: DP vs GREEDY-BY-RATIO", color=CYAN, fontsize=10, loc="left")
    ax.hist(gain, bins=bins, color=GREEN, alpha=0.85, edgecolor=BG)
    ax.axvline(gain.mean(), color="white", ls="--", lw=1.2)
    ax.set_xlabel("% extra paper profit with DP", color=MUTED)
    ax.text(0.97, 0.92, f"mean {gain.mean():+.2f}%", transform=ax.transAxes, ha="right", color="white", fontsize=10)

    ax = axs[0, 1]
    ax.set_title("2  REALISED PROFIT: v1 vs NEXUSROUTE 3.0", color=CYAN, fontsize=10, loc="left")
    ax.scatter(R["real_v1"], R["real_final"], c=GREEN, s=28, alpha=0.75, edgecolors="none")
    hi = max(R["real_v1"].max(), R["real_final"].max()) * 1.05
    ax.plot([0, hi], [0, hi], color=PINK, ls="--", lw=1, alpha=0.8)
    ax.set_xlabel("original v1 realised profit ($)", color=MUTED)
    ax.set_ylabel("NexusRoute 3.0 ($)", color=MUTED)
    ax.text(0.04, 0.92, "above dashed line = NexusRoute wins", transform=ax.transAxes, color=MUTED, fontsize=8)

    ax = axs[0, 2]
    ax.set_title("3  AVERAGE REALISED PROFIT BY STAGE", color=CYAN, fontsize=10, loc="left")
    means = [R["real_v1"].mean(), R["real_route"].mean(), R["real_final"].mean()]
    errs = [R["real_v1"].std(), R["real_route"].std(), R["real_final"].std()]
    bars = ax.bar(["V1 ORIGINAL", "+ ROUTING OPT", "+ REPAIR"], means, yerr=errs, color=[YELLOW, CYAN, GREEN],
                  capsize=4, ecolor=MUTED, edgecolor=BG)
    for b, v in zip(bars, means):
        ax.text(b.get_x() + b.get_width() / 2, v * 0.5, f"${v:.0f}", ha="center", color=BG, fontweight="bold", fontsize=11)
    ax.set_ylabel("mean realised profit ($)", color=MUTED)

    ax = axs[1, 0]
    ax.set_title("4  ON-TIME RATE PER CITY", color=CYAN, fontsize=10, loc="left")
    ax.scatter(R["ot_v1"], R["ot_final"], c=CYAN, s=26, alpha=0.7, edgecolors="none")
    ax.plot([0, 100], [0, 100], color=PINK, ls="--", lw=1, alpha=0.8)
    ax.set_xlabel("original v1 on-time %", color=MUTED)
    ax.set_ylabel("NexusRoute 3.0 on-time %", color=MUTED)

    ax = axs[1, 1]
    ax.set_title("5  ROUTE LENGTH vs HELD-KARP OPTIMUM", color=CYAN, fontsize=10, loc="left")
    if gg.size:
        ax.hist(gg, bins=bins, color=PURPLE, alpha=0.9, edgecolor=BG)
        ax.axvline(gg.mean(), color="white", ls="--", lw=1.2)
    ax.set_xlabel("% longer than the shortest possible tour (extra km buy punctuality)", color=MUTED, fontsize=8)

    ax = axs[1, 2]
    ax.set_title("6  DP RUNTIME SCALING  O(n·W)", color=CYAN, fontsize=10, loc="left")
    ax.plot(ns, scale, color=YELLOW, marker="o", lw=2, ms=6)
    ax.fill_between(ns, scale, color=YELLOW, alpha=0.1)
    ax.set_xlabel("number of parcels n  (W = 200 kg)", color=MUTED)
    ax.set_ylabel("ms", color=MUTED)

    fig.tight_layout(rect=(0, 0, 1, 0.91))
    fig.savefig(out_png, dpi=130, facecolor=BG)
    print(green(f"  Saved benchmark chart -> {Path(out_png).resolve()}"))
    return 0
