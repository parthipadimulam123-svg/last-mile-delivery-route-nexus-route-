"""FRONTEND - dark neon 3D dashboard.  Needs matplotlib (imported only when the GUI is used)."""
