"""Projector-friendly white-background theme: bold high-contrast colours."""
from __future__ import annotations

import matplotlib.patheffects as pe
from matplotlib.colors import LinearSegmentedColormap

BG     = "#FFFFFF"          # pure white background
PANEL  = "#F0F4FF"          # very light blue-white for side panels
CYAN   = "#0066CC"          # bold blue  (replaces neon cyan)
GREEN  = "#007A33"          # deep green (replaces neon green)
PINK   = "#CC0000"          # strong red  (replaces hot-pink)
YELLOW = "#E65C00"          # burnt orange  (replaces neon yellow – much better on projector)
PURPLE = "#6A0DAD"          # deep purple
TEXT   = "#111111"          # near-black text
MUTED  = "#444444"          # dark grey for secondary text


def _glow(width: float = 4, color: str = CYAN, alpha: float = 0.28):
    # On a white background a soft dark stroke works better than a glow
    return [pe.Stroke(linewidth=width, foreground=color, alpha=alpha * 0.6), pe.Normal()]


def _set3d(line, xs, ys, zs) -> None:
    line.set_data(xs, ys)
    line.set_3d_properties(zs)


def _style_2d(ax, title: str) -> None:
    ax.set_facecolor("#EEF3FF")          # light panel face
    for s in ax.spines.values():
        s.set_color(CYAN)
        s.set_linewidth(1.1)
    ax.tick_params(colors=MUTED, labelsize=6, length=2)
    ax.set_title(title, color=CYAN, fontsize=7.5, fontweight="bold", loc="left", pad=5)


NEXUS_CMAP = LinearSegmentedColormap.from_list(
    "nexus", ["#DDEEFF", "#99CCFF", "#3399FF", CYAN, GREEN]
)
