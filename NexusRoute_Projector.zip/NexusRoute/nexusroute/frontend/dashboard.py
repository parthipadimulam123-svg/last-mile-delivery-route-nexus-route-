"""FRONTEND - the interactive dark 3D dashboard (matplotlib) plus PNG / GIF export."""
from __future__ import annotations

import math
import random
import textwrap
import time
from collections import deque
from pathlib import Path
from types import SimpleNamespace
from typing import Deque, Optional, Tuple

import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, Rectangle
from matplotlib.widgets import Button, Slider
from mpl_toolkits.mplot3d.art3d import Line3DCollection

from ..backend.flight import build_flight
from ..backend.models import Config, generate_parcels
from ..backend.solver import ROUTE_LS, ROUTE_SA, Solution, solve
from ..backend.term import dim, green
from .theme import (BG, CYAN, GREEN, MUTED, NEXUS_CMAP, PANEL, PINK, PURPLE, TEXT, YELLOW,
                    _glow, _set3d, _style_2d)


class Dashboard:
    N_LOG = 23

    def __init__(self, cfg: Config, solution: Optional[Solution] = None,
                 frames_per_leg: int = 34, dwell: int = 9):
        self.cfg = cfg
        self.fpl, self.dwell = frames_per_leg, dwell
        self.pending_capacity, self.pending_n = cfg.capacity, cfg.n_parcels
        self.paused = False
        self.auto_rotate = True
        self.show_baseline = True
        self._dragging = False
        self.rot_rate = 0.32
        self.blit_on = False
        self._bg_cache = None
        self._last_t = None
        self._acc = 0.0
        self.play_fps = 30.0
        self.frame = 0
        self._ev_ptr = 0
        self.logs: Deque[Tuple[str, str]] = deque(maxlen=self.N_LOG)
        self.art = SimpleNamespace()
        self._build_figure()
        self.load(solution)

    # --------------------------------------------------------------------------------
    #  static figure skeleton
    # --------------------------------------------------------------------------------
    def _build_figure(self) -> None:
        plt.rcParams.update({
            "font.family": "monospace",
            "font.monospace": ["Consolas", "Share Tech Mono", "DejaVu Sans Mono", "Courier New"],
            "toolbar": "None", "text.parse_math": False,
            "text.color": TEXT, "axes.labelcolor": MUTED,
            "axes.facecolor": "#EEF3FF", "figure.facecolor": BG,
            "xtick.color": MUTED, "ytick.color": MUTED,
        })
        self.fig = plt.figure(figsize=(16, 9), facecolor=BG)
        try:
            self.fig.canvas.manager.set_window_title("NexusRoute 3.0 // Python Edition")
        except Exception:
            pass

        # ---- clean light background (projector-friendly) -----------------------------------
        bg = self.fig.add_axes([0, 0, 1, 1], zorder=0)
        bg.axis("off")
        bg.set_facecolor(BG)
        # panel frames — light blue fill with bold blue border
        for (x, y, w, h) in [(0.010, 0.025, 0.245, 0.895), (0.715, 0.025, 0.275, 0.895)]:
            bg.add_patch(Rectangle((x, y), w, h, facecolor=PANEL,
                                   edgecolor=CYAN, lw=1.5))
        bg.set_xlim(0, 1); bg.set_ylim(0, 1)

        # ---- header ------------------------------------------------------------------------
        self.fig.text(0.012, 0.962, "NEXUSROUTE 3.0", fontsize=23, fontweight="bold", color=CYAN,
                      path_effects=_glow(7, CYAN, 0.22), va="center")
        self.fig.text(0.255, 0.972, "PYTHON EDITION", fontsize=8.5, color=PURPLE, fontweight="bold", va="center")
        self.fig.text(0.255, 0.950,
                      "LAST-MILE 3D DRONE DELIVERY OPTIMIZER   //   0/1 KNAPSACK DP  ·  DEADLINE-AWARE GREEDY  ·  "
                      "2-OPT / OR-OPT  ·  SIMULATED ANNEALING  ·  HELD-KARP BENCHMARK",
                      fontsize=6.8, color=MUTED, va="center")
        self.fig.text(0.985, 0.972, "●  SYSTEM ONLINE", fontsize=9, color=GREEN, fontweight="bold",
                      ha="right", va="center", path_effects=_glow(5, GREEN, 0.2))
        self.txt_seed = self.fig.text(0.985, 0.949, "", fontsize=7, color=MUTED, ha="right", va="center")
        self.fig.add_artist(Line2D([0.010, 0.990], [0.932, 0.932], color=CYAN, alpha=0.35, lw=0.9))
        self.fig.text(0.5, 0.008, "SPACE pause   ·   E execute   ·   N new seed   ·   T rotate   ·   B baseline route   ·   "
                      "F fullscreen   ·   drag mouse to orbit   ·   Q quit", fontsize=6.5, color=MUTED, ha="center", va="bottom")

        # ---- KPI cards ---------------------------------------------------------------------
        self.ax_kpi = self.fig.add_axes([0.018, 0.618, 0.229, 0.297], zorder=2)
        self.ax_kpi.axis("off"); self.ax_kpi.set_xlim(0, 1); self.ax_kpi.set_ylim(0, 1)
        defs = [("CAPACITY USED", CYAN), ("MAX PROFIT (DP)", GREEN), ("ON-TIME DELIVERIES", YELLOW),
                ("EFFICIENCY", PURPLE), ("ROUTE DISTANCE", CYAN), ("REALISED PROFIT", GREEN)]
        self.kpi = []
        cw, ch, gx, gy = 0.485, 0.312, 0.03, 0.032
        for idx, (label, col) in enumerate(defs):
            r, c = divmod(idx, 2)
            x0, y0 = c * (cw + gx), 1 - (r + 1) * ch - r * gy
            self.ax_kpi.add_patch(Rectangle((x0, y0), cw, ch, facecolor="white", edgecolor=col, linewidth=1.2))
            self.ax_kpi.add_patch(Rectangle((x0, y0), 0.017, ch, facecolor=col, edgecolor="none"))
            self.ax_kpi.text(x0 + 0.045, y0 + ch * 0.78, label, fontsize=6.3, color=MUTED, va="center")
            v = self.ax_kpi.text(x0 + 0.045, y0 + ch * 0.46, "-", fontsize=14.5, fontweight="bold", color=col,
                                 va="center")
            s = self.ax_kpi.text(x0 + 0.045, y0 + ch * 0.14, "", fontsize=5.8, color=MUTED, va="center")
            self.kpi.append((v, s))

        # ---- console -----------------------------------------------------------------------
        self.ax_log = self.fig.add_axes([0.018, 0.215, 0.229, 0.385], zorder=2)
        _style_2d(self.ax_log, "SYSTEM CONSOLE")
        self.ax_log.set_xticks([]); self.ax_log.set_yticks([])
        self.ax_log.set_xlim(0, 1); self.ax_log.set_ylim(0, 1)
        self.log_txt = [self.ax_log.text(0.025, 0.968 - k * 0.0412, "", fontsize=6.5, va="center", color=MUTED)
                        for k in range(self.N_LOG)]

        # ---- controls ----------------------------------------------------------------------
        self.fig.text(0.018, 0.200, "MISSION PARAMETERS", fontsize=7.5, color=CYAN, fontweight="bold")
        ax_s1 = self.fig.add_axes([0.075, 0.158, 0.155, 0.017], zorder=3)
        ax_s2 = self.fig.add_axes([0.075, 0.122, 0.155, 0.017], zorder=3)
        self.s_cap = Slider(ax_s1, "", 20, 150, valinit=self.cfg.capacity, valstep=5, color=CYAN, valfmt="%d")
        self.s_n = Slider(ax_s2, "", 10, 60, valinit=self.cfg.n_parcels, valstep=1, color=PURPLE, valfmt="%d")
        self.fig.text(0.018, 0.1665, "CAP KG", fontsize=6.5, color=MUTED, va="center")
        self.fig.text(0.018, 0.1305, "PARCELS", fontsize=6.5, color=MUTED, va="center")
        for s in (self.s_cap, self.s_n):
            s.ax.set_facecolor("#DDEEFF")
            s.valtext.set_color(TEXT); s.valtext.set_fontsize(7)
            s.vline.set_visible(False)
            for sp in s.ax.spines.values():
                sp.set_color(CYAN)
        self.s_cap.on_changed(lambda v: setattr(self, "pending_capacity", int(v)))
        self.s_n.on_changed(lambda v: setattr(self, "pending_n", int(v)))

        def mk_button(rect, label, col, cb):
            ax = self.fig.add_axes(rect, zorder=3)
            b = Button(ax, label, color="#EEF3FF", hovercolor="#CCE0FF")
            b.label.set_color(col); b.label.set_fontsize(7.5); b.label.set_fontweight("bold")
            for sp in ax.spines.values():
                sp.set_color(col); sp.set_linewidth(1.8)
            b.on_clicked(cb)
            return b

        self.btn_exec = mk_button([0.018, 0.058, 0.229, 0.042], "EXECUTE OPTIMIZATION", CYAN,
                                  lambda e: self.execute())
        self.btn_seed = mk_button([0.018, 0.030, 0.110, 0.023], "NEW SEED", GREEN,
                                  lambda e: self.execute(new_seed=True))
        self.btn_rot = mk_button([0.137, 0.030, 0.110, 0.023], "ROTATE: ON", YELLOW,
                                 lambda e: self.toggle_rotate())

        # ---- right-hand analytics axes -----------------------------------------------------
        self.ax_dp = self.fig.add_axes([0.738, 0.700, 0.236, 0.200], zorder=2)
        self.ax_profit = self.fig.add_axes([0.738, 0.435, 0.066, 0.205], zorder=2)
        self.ax_real = self.fig.add_axes([0.823, 0.435, 0.066, 0.205], zorder=2)
        self.ax_dist = self.fig.add_axes([0.908, 0.435, 0.066, 0.205], zorder=2)
        self.ax_tl = self.fig.add_axes([0.795, 0.075, 0.180, 0.275], zorder=2)

        # ---- 3-D scene ---------------------------------------------------------------------
        self.ax3d = self.fig.add_axes([0.255, 0.105, 0.455, 0.825], projection="3d", zorder=1)
        self.ax_prog = self.fig.add_axes([0.285, 0.083, 0.395, 0.007], zorder=2)
        self.ax_prog.set_facecolor("#DDEEFF"); self.ax_prog.set_xticks([]); self.ax_prog.set_yticks([])
        for sp in self.ax_prog.spines.values():
            sp.set_color(CYAN)
        self.ax_prog.set_xlim(0, 1); self.ax_prog.set_ylim(0, 1)
        self.prog_bar = self.ax_prog.add_patch(Rectangle((0, 0), 0, 1, facecolor=CYAN, edgecolor="none"))

        handles = [
            Line2D([], [], marker="*", color="none", markerfacecolor=CYAN, markersize=11, label="Hub (depot)"),
            Line2D([], [], marker="o", color="none", markerfacecolor=GREEN, markersize=7, label="Selected · on time"),
            Line2D([], [], marker="o", color="none", markerfacecolor=YELLOW, markersize=7, label="Selected · late"),
            Line2D([], [], marker="o", color="none", markerfacecolor=PINK, markersize=7, alpha=0.8, label="Skipped"),
            Line2D([], [], marker="o", color="none", markerfacecolor="none", markeredgecolor=PURPLE, markeredgewidth=1.5,
                   markersize=7, label="DP pick dropped by repair"),
            Line2D([], [], marker="o", color="none", markerfacecolor="none", markeredgecolor=CYAN, markeredgewidth=1.2,
                   markersize=9, label="Added by repair"),
            Line2D([], [], color=CYAN, lw=2, label="Optimised route"),
            Line2D([], [], color=PURPLE, lw=1.4, ls="--", label="Original v1 route"),
        ]
        leg = self.fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.483, 0.027), ncol=4,
                              frameon=True, fontsize=6.6, labelcolor=TEXT, facecolor="white",
                              edgecolor=CYAN, columnspacing=1.6, handletextpad=0.5)
        leg.set_zorder(5)
        self.legend = leg

        # ---- interaction -------------------------------------------------------------------
        self.fig.canvas.mpl_connect("key_press_event", self._on_key)
        self.fig.canvas.mpl_connect("button_press_event",
                                    lambda e: setattr(self, "_dragging", e.inaxes is self.ax3d))
        self.fig.canvas.mpl_connect("button_release_event", lambda e: setattr(self, "_dragging", False))

    # --------------------------------------------------------------------------------
    #  loading / solving
    # --------------------------------------------------------------------------------
    def load(self, solution: Optional[Solution] = None) -> None:
        if solution is None:
            self.parcels = generate_parcels(self.cfg)
            solution = solve(self.cfg, self.parcels)
        self.sol = solution
        self.parcels = solution.parcels
        self.flight = build_flight(self.sol, self.fpl, self.dwell)
        self.txt_seed.set_text(f"SEED {self.cfg.seed}  ·  {len(self.parcels)} PARCELS  ·  CAP {self.cfg.capacity} KG")
        self._draw_kpis()
        self._draw_dp()
        self._draw_compare()
        self._draw_timeline()
        self._draw_scene()
        self.reset_playback()
        self._pipeline_logs()
        self.render_frame(0)
        self._mark_animated()

    def execute(self, new_seed: bool = False) -> None:
        """EXECUTE button: apply the slider values, re-run the full pipeline, replay the flight."""
        if new_seed:
            self.cfg.seed = random.randrange(100000, 999999)
        self.cfg.capacity = int(self.pending_capacity)
        self.cfg.n_parcels = int(self.pending_n)
        self.parcels = generate_parcels(self.cfg)
        self.load(solve(self.cfg, self.parcels))
        self.fig.canvas.draw_idle()

    def toggle_rotate(self) -> None:
        self.auto_rotate = not self.auto_rotate
        self.btn_rot.label.set_text("ROTATE: ON" if self.auto_rotate else "ROTATE: OFF")

    def reset_playback(self) -> None:
        self.frame = 0
        self._ev_ptr = 0
        self.logs.clear()

    def _on_key(self, e) -> None:
        k = (e.key or "").lower()
        if k == " ":
            self.paused = not self.paused
        elif k == "e":
            self.execute()
        elif k == "n":
            self.execute(new_seed=True)
        elif k == "t":
            self.toggle_rotate()
        elif k == "b":
            self.show_baseline = not self.show_baseline
            self.art.baseline.set_visible(self.show_baseline)

    # --------------------------------------------------------------------------------
    #  console
    # --------------------------------------------------------------------------------
    def _log(self, text: str, color: str = MUTED) -> None:
        lines = textwrap.wrap(text, 58, subsequent_indent="  ") or [""]
        for i, ln in enumerate(lines):
            self.logs.append((("> " if i == 0 else "") + ln, color))

    def _flush_logs(self) -> None:
        items = list(self.logs)
        for k, t in enumerate(self.log_txt):
            if k < len(items):
                t.set_text(items[k][0]); t.set_color(items[k][1])
            else:
                t.set_text("")

    def _pipeline_logs(self) -> None:
        s, k, b = self.sol, self.sol.knap, self.sol.best
        base = s.baseline
        self._log("System initialised. Ready for routing calculation...", MUTED)
        self._log("Executing Dynamic Programming Knapsack engine...", CYAN)
        self._log(f"DP solved in {k.runtime_ms:.1f} ms: {len(s.dp_set)} parcels, ${k.profit}, "
                  f"{k.weight}/{self.cfg.capacity} kg", GREEN)
        g = 100 * (k.profit - s.greedy_profit) / s.greedy_profit if s.greedy_profit else 0
        self._log(f"Greedy-by-ratio only ${s.greedy_profit} -> DP {g:+.1f}% better", TEXT)
        self._log(f"Original greedy NN: {base.n_on_time}/{len(base.stops)} on time, realised ${base.realised_profit}", YELLOW)
        rp = s.repair
        if rp.moves:
            self._log("Deadline-aware repair engaged...", CYAN)
            for desc, real in rp.moves[:3]:
                self._log(f"{' '.join(desc.split())}  -> realised ${real}", PURPLE)
            if len(rp.moves) > 3:
                self._log(f"... +{len(rp.moves) - 3} more moves", MUTED)
        else:
            self._log("Repair: DP load already best for deadlines.", PURPLE)
        ls = s.routes[ROUTE_LS]; sa = s.routes[ROUTE_SA]
        self._log(f"2-opt+Or-opt: {ls.n_on_time}/{len(ls.stops)} on time, dist {ls.distance:.0f}; "
                  f"SA: {sa.n_on_time}/{len(sa.stops)}, {sa.distance:.0f}", CYAN)
        if s.hk_distance is not None:
            self._log(f"Held-Karp exact shortest tour = {s.hk_distance:.0f} (benchmark)", PURPLE)
        self._log(f"Best route: {b.name}. Realised ${b.realised_profit} "
                  f"(was ${base.realised_profit}). Efficiency {b.efficiency:.1f}%", GREEN)
        self._log("Launching drone...", CYAN)

    # --------------------------------------------------------------------------------
    #  panels
    # --------------------------------------------------------------------------------
    def _draw_kpis(self) -> None:
        s, k, b, base = self.sol, self.sol.knap, self.sol.best, self.sol.baseline
        cap = self.cfg.capacity
        m = len(b.stops)
        g = 100 * (k.profit - s.greedy_profit) / s.greedy_profit if s.greedy_profit else 0.0
        gain = 100 * (b.realised_profit - base.realised_profit) / base.realised_profit if base.realised_profit else 0.0
        if s.hk_distance:
            dist_sub = f"Held-Karp optimum {s.hk_distance:.0f} ({100 * (b.distance - s.hk_distance) / s.hk_distance:+.1f}%)"
        else:
            dist_sub = f"{100 * (b.distance - base.distance) / max(base.distance, 1e-9):+.1f}% vs original route"
        vals = [
            (f"{s.final_weight} / {cap} KG", f"{100 * s.final_weight / cap:.1f}% load factor"),
            (f"${k.profit}", f"paper optimum, {g:+.1f}% vs greedy"),
            (f"{b.n_on_time} / {m}", f"original v1: {base.n_on_time} / {len(base.stops)}"),
            (f"{b.efficiency:.1f}%", f"{b.efficiency - base.efficiency:+.1f} pp vs original v1"),
            (f"{b.distance:.0f} u", dist_sub),
            (f"${b.realised_profit}", f"{gain:+.0f}% vs original (${base.realised_profit})"),
        ]
        for (vt, st), (v, sub) in zip(self.kpi, vals):
            vt.set_text(v); st.set_text(sub)

    def _draw_dp(self) -> None:
        ax, k = self.ax_dp, self.sol.knap
        ax.cla()
        _style_2d(ax, "DP TABLE  dp[i][w]  +  BACKTRACK PATH")
        ax.imshow(k.table, cmap=NEXUS_CMAP, aspect="auto", origin="upper", interpolation="nearest")
        ws = [p[0] for p in k.path]; is_ = [p[1] for p in k.path]
        ax.plot(ws, is_, color="white", lw=0.9, alpha=0.85)
        if k.taken_cells:
            ax.scatter([c[0] for c in k.taken_cells], [c[1] for c in k.taken_cells], s=16, c=GREEN,
                       edgecolors="white", linewidths=0.5, zorder=3)
        ax.set_xlabel("capacity w (kg)", fontsize=6, color=MUTED, labelpad=1)
        ax.set_ylabel("parcels considered i", fontsize=6, color=MUTED, labelpad=1)
        ax.text(0.98, 0.04, f"dp[n][W] = ${k.profit}", transform=ax.transAxes, ha="right", fontsize=7,
                color=GREEN, fontweight="bold", path_effects=[pe.withStroke(linewidth=2, foreground=BG)])

    def _bars(self, ax, title, names, vals, cols, subs=None, edge_idx=None) -> None:
        ax.cla(); _style_2d(ax, title)
        top = max(vals) if vals and max(vals) > 0 else 1.0
        bars = ax.bar(range(len(vals)), vals, color=cols, width=0.66, edgecolor=(1, 1, 1, 0.25))
        if edge_idx is not None:
            bars[edge_idx].set_edgecolor("white"); bars[edge_idx].set_linewidth(1.6)
        ax.set_xticks(range(len(vals))); ax.set_xticklabels(names, fontsize=5.4)
        ax.set_yticks([]); ax.set_ylim(0, top * 1.25)
        for i, v in enumerate(vals):
            ax.text(i, v + top * 0.02, f"{v:.0f}", ha="center", fontsize=6.2, color=TEXT, fontweight="bold")
            if subs:
                ax.text(i, top * 0.035, subs[i], ha="center", fontsize=5.2, color=BG, fontweight="bold")
        for sp in ("top", "right", "left"):
            ax.spines[sp].set_visible(False)

    def _draw_compare(self) -> None:
        s = self.sol
        self._bars(self.ax_profit, "PAPER $", ["GRDY", "DP*", "LP"], [s.greedy_profit, s.knap.profit, s.lp_bound],
                   [MUTED, GREEN, PURPLE])
        base, mid, fin = s.baseline, s.dp_suite.best, s.best
        self._bars(self.ax_real, "REALISED $", ["V1", "+ROUTE", "+FIX"],
                   [base.realised_profit, mid.realised_profit, fin.realised_profit], [YELLOW, CYAN, GREEN],
                   subs=[f"{r.n_on_time}/{len(r.stops)}" for r in (base, mid, fin)], edge_idx=2)
        names, vals, cols, subs = ["NN", "2OPT", "SA"], [], [YELLOW, CYAN, GREEN], []
        for r in s.routes.values():
            vals.append(r.distance); subs.append(f"{r.n_on_time}/{len(r.stops)}")
        if s.hk_distance is not None:
            names.append("HK"); vals.append(s.hk_distance); cols.append(PURPLE); subs.append("opt")
        idx = list(s.routes.values()).index(s.best)
        self._bars(self.ax_dist, "DISTANCE", names, vals, cols, subs=subs, edge_idx=idx)

    def _draw_timeline(self) -> None:
        ax, b = self.ax_tl, self.sol.best
        ax.cla(); _style_2d(ax, "DELIVERY TIMELINE  (arrival vs deadline)")
        m = len(b.stops)
        if m:
            ys = np.arange(m)
            cols = [GREEN if ok else YELLOW for ok in b.on_time]
            ax.barh(ys, b.arrivals, color=cols, alpha=0.75, height=0.58, edgecolor="none")
            ax.scatter(b.deadlines, ys, marker="|", s=110, c="white", linewidths=1.8, zorder=3)
            ax.set_yticks(ys)
            ax.set_yticklabels([f"#{i + 1} {p.name}" for i, p in enumerate(b.stops)], fontsize=5.8)
            ax.invert_yaxis()
            total = b.distance / self.cfg.speed
            xmax = max(max(b.arrivals), max(b.deadlines), total) * 1.06
            ax.axvline(total, color=PURPLE, ls="--", lw=0.9, alpha=0.8)
            ax.text(total, -0.42, "RTB ", color=PURPLE, fontsize=5.8, ha="right", va="top")
            ax.set_xlim(0, xmax)
        ax.set_xlabel("mission time    white tick = deadline", fontsize=6, color=MUTED, labelpad=1)
        ax.grid(axis="x", color=CYAN, alpha=0.08)
        self.art.nowline = ax.axvline(0, color="white", lw=1.2, alpha=0.9)

    # --------------------------------------------------------------------------------
    #  3-D scene
    # --------------------------------------------------------------------------------
    def _draw_scene(self) -> None:
        ax, s, cfg = self.ax3d, self.sol, self.cfg
        elev, azim = (ax.elev, ax.azim) if getattr(self, "_scene_drawn", False) else (27, -58)
        ax.cla(); ax.set_axis_off(); ax.patch.set_alpha(0)
        lim, floor = cfg.area / 2 + 10, -25.0
        ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(floor, 50)
        try:
            ax.set_box_aspect((1, 1, 0.40), zoom=1.38)
        except TypeError:
            ax.set_box_aspect((1, 1, 0.40))
        ax.view_init(elev=elev, azim=azim)
        self._scene_drawn = True

        # -- floor grid + radar rings (light blue on white) --
        g = np.linspace(-lim, lim, 15)
        segs = [[(x, -lim, floor), (x, lim, floor)] for x in g] + [[(-lim, y, floor), (lim, y, floor)] for y in g]
        ax.add_collection3d(Line3DCollection(segs, colors=CYAN, linewidths=0.6, alpha=0.30))
        th = np.linspace(0, 2 * np.pi, 120)
        for r in (40, 80, 120):
            ax.plot(r * np.cos(th), r * np.sin(th), np.full_like(th, floor), color=CYAN, lw=0.9, alpha=0.45)
        ax.plot([-lim, lim], [0, 0], [floor, floor], color=CYAN, lw=1.0, alpha=0.5)
        ax.plot([0, 0], [-lim, lim], [floor, floor], color=CYAN, lw=1.0, alpha=0.5)

        # -- hub --
        ax.plot([0, 0], [0, 0], [floor, 0], color=CYAN, lw=1.5, alpha=0.8)
        ax.scatter([0], [0], [0], s=520, c=CYAN, alpha=0.15, depthshade=False, lw=0)
        ax.scatter([0], [0], [0], s=230, c=CYAN, marker="*", depthshade=False, edgecolors="#003399", linewidths=0.8)
        ax.text(0, 0, 9, "HUB", color=CYAN, fontsize=7.5, fontweight="bold", ha="center",
                path_effects=[pe.withStroke(linewidth=2, foreground="white")])

        # -- parcels --
        def stems(ps, col, a):
            if ps:
                ax.add_collection3d(Line3DCollection([[(p.x, p.y, p.z), (p.x, p.y, floor)] for p in ps],
                                                     colors=col, linewidths=0.7, alpha=a))
                ax.scatter([p.x for p in ps], [p.y for p in ps], [floor] * len(ps), s=14, c=col, alpha=0.40,
                           depthshade=False, lw=0)

        def bubbles(ps, col, a, glow_a):
            if not ps:
                return
            xs, ys, zs = [p.x for p in ps], [p.y for p in ps], [p.z for p in ps]
            sz = np.array([40 + p.profit * 2.3 for p in ps])
            ax.scatter(xs, ys, zs, s=sz * 2.5, c=col, alpha=glow_a * 0.5, depthshade=False, lw=0)
            ax.scatter(xs, ys, zs, s=sz, c=col, alpha=a, depthshade=False, edgecolors="white", linewidths=0.8)

        b = self.sol.best
        status = {p.id: ok for p, ok in zip(b.stops, b.on_time)}
        sel_ok = [p for p in s.selected if status.get(p.id, False)]
        sel_late = [p for p in s.selected if not status.get(p.id, True)]
        if s.dropped:                                   # DP picks the repair replaced -> hollow purple ring
            stems(s.dropped, PURPLE, 0.35)
            ax.scatter([p.x for p in s.dropped], [p.y for p in s.dropped], [p.z for p in s.dropped],
                       s=[40 + p.profit * 2.3 for p in s.dropped], facecolors="none", edgecolors=PURPLE,
                       linewidths=1.5, depthshade=False)
            for p in s.dropped:
                ax.text(p.x, p.y, p.z + 6, p.name, color=PURPLE, fontsize=5.5, ha="center")
        if s.added:                                     # parcels the repair brought in -> cyan halo
            ax.scatter([p.x for p in s.added], [p.y for p in s.added], [p.z for p in s.added],
                       s=[(40 + p.profit * 2.3) * 2.3 for p in s.added], facecolors="none",
                       edgecolors=CYAN, linewidths=1.2, alpha=0.9, depthshade=False)

        stems(s.skipped, PINK, 0.20); stems(sel_ok, GREEN, 0.45); stems(sel_late, YELLOW, 0.45)
        bubbles(s.skipped, PINK, 0.55, 0.10)
        bubbles(sel_ok, GREEN, 0.95, 0.20)
        bubbles(sel_late, YELLOW, 0.95, 0.20)
        for p in s.skipped:
            ax.text(p.x, p.y, p.z + 4.5, p.name[1:], color=PINK, fontsize=5, alpha=0.7, ha="center")
        for k, p in enumerate(b.stops):
            col = GREEN if b.on_time[k] else YELLOW
            ax.text(p.x, p.y, p.z + 9.5, f"{k + 1}", color=TEXT, fontsize=9, fontweight="bold", ha="center",
                    path_effects=[pe.withStroke(linewidth=2.2, foreground=col)])
            ax.text(p.x, p.y, p.z - 9, f"${p.profit}·{p.weight}kg", color=col, fontsize=5.3, ha="center", alpha=1.0)

        # -- routes --
        base = s.baseline
        bp = np.array([[0, 0, 0]] + [q.pos for q in base.stops] + [[0, 0, 0]])
        (self.art.baseline,) = ax.plot(bp[:, 0], bp[:, 1], bp[:, 2], color=PURPLE, lw=1.3, ls="--", alpha=0.70)
        self.art.baseline.set_visible(self.show_baseline and base.order != b.order)
        rp = np.array([[0, 0, 0]] + [q.pos for q in b.stops] + [[0, 0, 0]])
        for lw, a in ((6, 0.10), (3, 0.18)):
            ax.plot(rp[:, 0], rp[:, 1], rp[:, 2], color=CYAN, lw=lw, alpha=a)
        ax.plot(rp[:, 0], rp[:, 1], rp[:, 2], color=CYAN, lw=2.0, alpha=0.75)

        # -- animated artists --
        (self.art.flown_glow,) = ax.plot([], [], [], color=CYAN, lw=7, alpha=0.25)
        (self.art.flown,) = ax.plot([], [], [], color=CYAN, lw=2.5, alpha=1.0)
        (self.art.alt,) = ax.plot([], [], [], color=CYAN, lw=0.9, ls=":", alpha=0.8)
        (self.art.drone_glow,) = ax.plot([], [], [], marker="o", ms=24, color=CYAN, alpha=0.20, ls="none")
        (self.art.drone,) = ax.plot([], [], [], marker="D", ms=9, mfc="white", mec=CYAN, mew=2.2, ls="none")
        (self.art.ring,) = ax.plot([], [], [], lw=2.0, color=GREEN)
        self.art.tele = ax.text2D(0.015, 0.985, "", transform=ax.transAxes, fontsize=7.8, color=CYAN,
                                  va="top", fontweight="bold", linespacing=1.5,
                                  path_effects=[pe.withStroke(linewidth=2.5, foreground="white")])

    # --------------------------------------------------------------------------------
    #  per-frame update  (used by the live animation AND the GIF exporter)
    # --------------------------------------------------------------------------------
    def render_frame(self, i: int, steps: float = 1.0):
        f, a = self.flight, self.art
        i = int(min(max(i, 0), f.n - 1))
        x, y, z = f.pts[i]

        # events -> console
        while self._ev_ptr < len(f.events) and f.events[self._ev_ptr][0] <= i:
            _, kind, msg = f.events[self._ev_ptr]
            self._log(msg, {"ok": GREEN, "late": PINK, "done": CYAN}[kind])
            self._ev_ptr += 1
        self._flush_logs()

        # drone, altimeter beam, flown trail
        pulse = 1.0 + 0.25 * math.sin(i * 0.4)
        _set3d(a.drone, [x], [y], [z])
        _set3d(a.drone_glow, [x], [y], [z]); a.drone_glow.set_markersize(22 * pulse)
        _set3d(a.alt, [x, x], [y, y], [z, -25.0])
        _set3d(a.flown, f.pts[:i + 1, 0], f.pts[:i + 1, 1], f.pts[:i + 1, 2])
        _set3d(a.flown_glow, f.pts[:i + 1, 0], f.pts[:i + 1, 1], f.pts[:i + 1, 2])

        # drop-off shock-wave
        k = int(f.dwell_k[i])
        if k >= 0:
            p = f.dwell_p[i]
            th = np.linspace(0, 2 * np.pi, 48)
            r = 3 + 16 * p
            ok = self.sol.best.on_time[k]
            a.ring.set_color(GREEN if ok else YELLOW); a.ring.set_alpha(max(0.0, 1 - p))
            _set3d(a.ring, x + r * np.cos(th), y + r * np.sin(th), np.full_like(th, z))
            a.ring.set_visible(True)
        else:
            a.ring.set_visible(False)

        # telemetry
        m = len(self.sol.best.stops)
        if k >= 0:
            status = f"DROP-OFF  #{k + 1}  {self.sol.best.stops[k].name}"
        elif i >= f.n - 1 or (f.leg[i] >= m and i > f.n - 20):
            status = "MISSION COMPLETE"
        elif f.leg[i] < m:
            status = f"EN ROUTE  ->  #{f.leg[i] + 1}  {self.sol.best.stops[f.leg[i]].name}"
        else:
            status = "RETURNING TO HUB"
        a.tele.set_text(f"T+ {f.t[i]:6.1f}    ALT {z:5.1f} m    PAYLOAD {int(f.payload[i]):3d} kg    "
                        f"DELIVERED {int(f.delivered[i])}/{m}\nSTATUS: {status}")
        a.nowline.set_xdata([f.t[i], f.t[i]])
        self.prog_bar.set_width(i / max(1, f.n - 1))

        # camera orbit
        if self.auto_rotate and not self._dragging:
            self.ax3d.view_init(elev=self.ax3d.elev, azim=self.ax3d.azim + self.rot_rate * steps)
        return ()

    # --------------------------------------------------------------------------------
    #  LIVE MODE: time-based playback + blitting (only the moving parts are redrawn)
    # --------------------------------------------------------------------------------
    def _animated_artists(self) -> list:
        return [self.nowline, self.prog_bar, *self.log_txt, self.ax3d, self.legend]

    def _mark_animated(self) -> None:
        if self.blit_on:
            for art in self._animated_artists():
                art.set_animated(True)
            self._bg_cache = None
            self.fig.canvas.draw_idle()

    def _on_draw(self, _event) -> None:
        """Full redraw happened: cache the static picture, then paint the animated layer on top."""
        if not self.blit_on:
            return
        self._bg_cache = self.fig.canvas.copy_from_bbox(self.fig.bbox)
        for art in self._animated_artists():
            self.fig.draw_artist(art)

    def _blit(self) -> None:
        cv = self.fig.canvas
        try:
            if self._bg_cache is None:
                cv.draw()                       # fires draw_event -> caches the static picture
                return
            cv.restore_region(self._bg_cache)
            for art in self._animated_artists():
                self.fig.draw_artist(art)
            cv.blit(self.fig.bbox)
        except Exception:                       # backend without blit support -> plain redraws
            self._disable_blit()

    def _disable_blit(self) -> None:
        self.blit_on = False
        for art in self._animated_artists():
            art.set_animated(False)
        self._bg_cache = None
        self.fig.canvas.draw_idle()

    @property
    def nowline(self):
        return self.art.nowline

    def live_tick(self) -> None:
        """Timer callback.  Advances the flight by REAL elapsed time so speed is the same on any PC."""
        if getattr(self, "_busy", False):          # never run two ticks at once
            return
        self._busy = True
        try:
            self._live_tick_body()
        finally:
            self._busy = False

    def _live_tick_body(self) -> None:
        now = time.perf_counter()
        dt = 0.0 if self._last_t is None else min(now - self._last_t, 0.25)
        self._last_t = now
        steps = dt * self.play_fps
        self._acc += steps
        adv = int(self._acc)
        self._acc -= adv
        if not self.paused and self.frame < self.flight.n - 1:
            self.frame = min(self.flight.n - 1, self.frame + adv)
        self.render_frame(self.frame, steps)
        if self.blit_on:
            self._blit()
        else:
            self.fig.canvas.draw_idle()

    def run(self) -> None:
        self.blit_on = True
        self.fig.canvas.mpl_connect("draw_event", self._on_draw)
        self._mark_animated()
        self.timer = self.fig.canvas.new_timer(interval=15)
        self.timer.add_callback(self.live_tick)
        self.timer.start()
        plt.show()


def save_png(dash: Dashboard, path: str, dpi: int = 120) -> None:
    dash.auto_rotate = False
    dash._ev_ptr = 0                                   # keep pipeline logs, append the flight events
    dash.render_frame(dash.flight.n - 1)
    dash.fig.savefig(path, dpi=dpi, facecolor=BG)
    print(green(f"  Saved dashboard snapshot -> {Path(path).resolve()}"))


def save_gif(dash: Dashboard, path: str, fps: int = 20, dpi: int = 70, stride: int = 1) -> None:
    from matplotlib.animation import FuncAnimation, PillowWriter
    dash.reset_playback()
    dash._pipeline_logs()
    dash.rot_rate *= max(1, stride)
    frames = list(range(0, dash.flight.n, max(1, stride)))
    print(dim(f"  Rendering {len(frames)} frames ... (this can take a minute)"))
    anim = FuncAnimation(dash.fig, dash.render_frame, frames=frames, blit=False)
    anim.save(path, writer=PillowWriter(fps=fps), dpi=dpi, savefig_kwargs={"facecolor": BG})
    print(green(f"  Saved animation -> {Path(path).resolve()}"))
