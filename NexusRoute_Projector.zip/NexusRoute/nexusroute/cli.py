"""Command line interface - chooses the matplotlib backend, then runs the requested mode."""
from __future__ import annotations

import argparse
import random
import sys
from typing import Optional, Sequence

from .backend.models import Config, generate_parcels
from .backend.report import banner, export_results, print_report
from .backend.solver import solve

HEADLESS_FLAGS = ("--no-gui", "--save-png", "--save-gif", "--benchmark", "--selftest")


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="run.py",
        description="NexusRoute 3.0 - Knapsack DP + deadline-aware routing (2-opt, SA, Held-Karp) "
                    "with a live 3D dark-mode dashboard.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="examples:\n  python run.py\n  python run.py --seed 42 -c 80\n"
               "  python run.py --benchmark 100\n  python run.py --save-gif demo.gif")
    p.add_argument("-n", "--parcels", type=int, default=30, help="number of candidate parcels (default 30)")
    p.add_argument("-c", "--capacity", type=int, default=60, help="drone capacity in kg (default 60)")
    p.add_argument("--seed", type=int, default=None, help="random seed (default: random, printed)")
    p.add_argument("--speed", type=float, default=1.0, help="drone speed in distance units / time unit")
    p.add_argument("--late-penalty", type=float, default=60.0, help="routing cost per late parcel")
    p.add_argument("--sa-iters", type=int, default=12000, help="simulated annealing iterations")
    p.add_argument("--no-repair", action="store_true", help="disable STAGE 3 (shows the pure original pipeline)")
    p.add_argument("--no-gui", action="store_true", help="console report only")
    p.add_argument("--save-png", metavar="FILE", help="save a dashboard snapshot and exit")
    p.add_argument("--save-gif", metavar="FILE", help="render the flight animation to a GIF and exit")
    p.add_argument("--gif-fps", type=int, default=20)
    p.add_argument("--gif-dpi", type=int, default=70)
    p.add_argument("--gif-stride", type=int, default=2, help="render every k-th frame (default 2)")
    p.add_argument("--dpi", type=int, default=120, help="PNG resolution (default 120 -> 1920x1080)")
    p.add_argument("--frames-per-leg", type=int, default=34, help="animation smoothness (default 34)")
    p.add_argument("--benchmark", type=int, metavar="N", help="Monte-Carlo benchmark over N random cities")
    p.add_argument("--bench-out", default="nexusroute_benchmark.png", help="benchmark chart filename")
    p.add_argument("--export", metavar="DIR", help="write report.json and route.csv into DIR")
    p.add_argument("--selftest", action="store_true", help="run the correctness test-suite")
    a = p.parse_args(argv)
    if not 1 <= a.parcels <= 200:
        p.error("--parcels must be between 1 and 200")
    if not 1 <= a.capacity <= 1000:
        p.error("--capacity must be between 1 and 1000 (kg)")
    if a.speed <= 0:
        p.error("--speed must be positive")
    if a.sa_iters < 0 or a.late_penalty < 0:
        p.error("--sa-iters and --late-penalty must not be negative")
    if a.benchmark is not None and a.benchmark < 1:
        p.error("--benchmark needs at least 1 trial")
    return a


def main(argv: Optional[Sequence[str]] = None) -> int:
    a = parse_args(argv)
    headless = any(flag in (argv or sys.argv[1:]) or any(x.startswith(flag + "=") for x in (argv or sys.argv[1:]))
                   for flag in HEADLESS_FLAGS)
    if headless:                                   # must be decided BEFORE pyplot is imported anywhere
        import matplotlib
        matplotlib.use("Agg")

    if a.selftest:
        from .selftest import run_selftest
        return run_selftest()

    cfg = Config(n_parcels=a.parcels, capacity=a.capacity, seed=a.seed, speed=a.speed,
                 late_penalty=a.late_penalty, sa_iters=a.sa_iters, repair=not a.no_repair)
    if cfg.seed is None:
        cfg.seed = random.randrange(100000, 999999)

    if a.benchmark:
        from .benchmark import run_benchmark
        return run_benchmark(a.benchmark, cfg, a.bench_out)

    banner()
    sol = solve(cfg, generate_parcels(cfg))
    print_report(sol)
    if a.export:
        export_results(sol, a.export)
    if a.no_gui:
        return 0

    from .frontend.dashboard import Dashboard, save_gif, save_png
    dash = Dashboard(cfg, sol, frames_per_leg=a.frames_per_leg)
    if a.save_png:
        save_png(dash, a.save_png, a.dpi)
    if a.save_gif:
        save_gif(dash, a.save_gif, a.gif_fps, a.gif_dpi, a.gif_stride)
    if not (a.save_png or a.save_gif):
        dash.run()
    return 0
