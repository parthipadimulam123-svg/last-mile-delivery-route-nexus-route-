"""STAGE 2 - routing algorithms: greedy NN, 2-opt/Or-opt, simulated annealing, Held-Karp exact."""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np

from .models import Config, Parcel

@dataclass
class RouteResult:
    name: str
    order: List[int]            # visit order as indices into the SELECTED list
    stops: List[Parcel]         # same order, as Parcel objects
    distance: float             # full closed tour hub -> ... -> hub
    arrivals: List[float]       # arrival time at every stop
    deadlines: List[int]
    on_time: List[bool]
    cost: float
    runtime_ms: float

    @property
    def n_on_time(self) -> int:
        return sum(self.on_time)

    @property
    def efficiency(self) -> float:
        return 100.0 * self.n_on_time / len(self.stops) if self.stops else 0.0

    @property
    def total_lateness(self) -> float:
        return sum(max(0.0, a - d) for a, d in zip(self.arrivals, self.deadlines))

    @property
    def realised_profit(self) -> int:
        return sum(p.profit for p, ok in zip(self.stops, self.on_time) if ok)


class RoutingProblem:
    """Pre-computes the distance matrix for hub + selected parcels (hub = index 0)."""

    def __init__(self, selected: Sequence[Parcel], cfg: Config):
        self.parcels = list(selected)
        self.m = len(self.parcels)
        self.speed = cfg.speed
        self.pen = cfg.late_penalty
        pts = np.vstack([np.zeros(3)] + [p.pos for p in self.parcels]) if self.m else np.zeros((1, 3))
        self.D = np.linalg.norm(pts[:, None, :] - pts[None, :, :], axis=2)
        self.Dl = self.D.tolist()                       # python lists are faster in tight loops
        self.dl = [0.0] + [float(p.deadline) for p in self.parcels]

    # fast scalar objective used inside the search loops --------------------------------
    def cost(self, order: Sequence[int]) -> float:
        D, dl, sp = self.Dl, self.dl, self.speed
        dist, prev, n_late, amt = 0.0, 0, 0, 0.0
        for i in order:
            j = i + 1
            dist += D[prev][j]
            prev = j
            t = dist / sp
            if t > dl[j]:
                n_late += 1
                amt += t - dl[j]
        dist += D[prev][0]
        return dist + self.pen * n_late + amt

    # full evaluation used for reporting -------------------------------------------------
    def evaluate(self, name: str, order: Sequence[int], runtime_ms: float = 0.0) -> RouteResult:
        D, sp = self.Dl, self.speed
        dist, prev = 0.0, 0
        arrivals: List[float] = []
        for i in order:
            dist += D[prev][i + 1]
            prev = i + 1
            arrivals.append(dist / sp)
        dist += D[prev][0]
        stops = [self.parcels[i] for i in order]
        deadlines = [p.deadline for p in stops]
        on_time = [a <= d + 1e-9 for a, d in zip(arrivals, deadlines)]
        return RouteResult(name, list(order), stops, dist, arrivals, deadlines, on_time,
                           self.cost(order), runtime_ms)


def nearest_neighbour_deadline_aware(prob: RoutingProblem, penalty: float) -> List[int]:
    """
    ORIGINAL heuristic (ported 1:1 from the JavaScript file).
    At every step choose the unvisited parcel with the smallest score
        score = distance_to_it + penalty   if we would already miss its deadline
              = distance_to_it             otherwise
    Greedy => fast O(m^2) but myopic: it never looks ahead.
    """
    remaining = list(range(prob.m))
    order: List[int] = []
    pos, t = 0, 0.0
    while remaining:
        def score(i: int) -> float:
            d = prob.Dl[pos][i + 1]
            return d + (penalty if prob.dl[i + 1] < t + d else 0.0)
        nxt = min(remaining, key=score)
        remaining.remove(nxt)
        t += prob.Dl[pos][nxt + 1] / prob.speed
        pos = nxt + 1
        order.append(nxt)
    return order


def local_search(prob: RoutingProblem, start: Sequence[int]) -> List[int]:
    """
    2-opt  : reverse a segment of the tour      (removes crossing edges)
    Or-opt : move a block of 1-3 parcels elsewhere
    Repeated (first-improvement) until no move lowers the cost -> a local optimum.
    """
    best = list(start)
    best_c = prob.cost(best)
    m = len(best)
    improved = True
    while improved:
        improved = False
        for i in range(m - 1):                                   # ---- 2-opt
            for j in range(i + 1, m):
                cand = best[:i] + best[i:j + 1][::-1] + best[j + 1:]
                c = prob.cost(cand)
                if c < best_c - 1e-9:
                    best, best_c, improved = cand, c, True
        for seg in (1, 2, 3):                                    # ---- Or-opt
            i = 0
            while i <= m - seg:
                block, rest = best[i:i + seg], best[:i] + best[i + seg:]
                for k in range(len(rest) + 1):
                    if k == i:
                        continue
                    cand = rest[:k] + block + rest[k:]
                    c = prob.cost(cand)
                    if c < best_c - 1e-9:
                        best, best_c, improved = cand, c, True
                        break
                i += 1
    return best


def simulated_annealing(prob: RoutingProblem, start: Sequence[int],
                        rng: random.Random, iters: int) -> List[int]:
    """
    Simulated Annealing: accept worse routes with probability exp(-delta / T) while the
    temperature T cools geometrically.  Early on it explores freely, later it behaves like
    a hill-climber.  Moves: segment reversal, swap, relocate.  Returns the best route seen.
    """
    m = len(start)
    cur = list(start)
    if m < 3:
        return cur
    cur_c = prob.cost(cur)
    best, best_c = cur[:], cur_c
    t0, t1 = max(1.0, 0.05 * cur_c), 0.01
    alpha = (t1 / t0) ** (1.0 / max(1, iters))
    T = t0
    for _ in range(iters):
        i, j = sorted(rng.sample(range(m), 2))
        r = rng.random()
        cand = cur[:]
        if r < 0.45:
            cand[i:j + 1] = cand[i:j + 1][::-1]
        elif r < 0.70:
            cand[i], cand[j] = cand[j], cand[i]
        else:
            cand.insert(j, cand.pop(i))
        c = prob.cost(cand)
        d = c - cur_c
        if d < 0 or rng.random() < math.exp(-d / T):
            cur, cur_c = cand, c
            if c < best_c - 1e-9:
                best, best_c = cand[:], c
        T *= alpha
    return best


def held_karp(D: np.ndarray) -> Tuple[float, List[int]]:
    """
    EXACT shortest closed tour (hub -> all parcels -> hub) by Held-Karp bitmask DP.
        dp[mask][j] = shortest path from hub visiting exactly the parcels in `mask`, ending at j
    Time O(2^m * m^2).  Used as a lower-bound benchmark (it ignores deadlines).
    """
    m = D.shape[0] - 1
    if m == 0:
        return 0.0, []
    if m == 1:
        return float(D[0, 1] + D[1, 0]), [0]
    Dl = D.tolist()
    INF = float("inf")
    full = (1 << m) - 1
    dp = [[INF] * m for _ in range(1 << m)]
    par = [[-1] * m for _ in range(1 << m)]
    for j in range(m):
        dp[1 << j][j] = Dl[0][j + 1]
    for mask in range(1, 1 << m):
        row = dp[mask]
        for last in range(m):
            cur = row[last]
            if cur == INF:
                continue
            for nxt in range(m):
                bit = 1 << nxt
                if mask & bit:
                    continue
                nm = mask | bit
                v = cur + Dl[last + 1][nxt + 1]
                if v < dp[nm][nxt]:
                    dp[nm][nxt] = v
                    par[nm][nxt] = last
    best, last = min((dp[full][j] + Dl[j + 1][0], j) for j in range(m))
    order, mask = [], full
    while last != -1:
        order.append(last)
        prev = par[mask][last]
        mask ^= 1 << last
        last = prev
    order.reverse()
    return float(best), order
