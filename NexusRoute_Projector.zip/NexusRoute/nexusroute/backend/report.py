"""Terminal report and JSON/CSV export of a solved instance."""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, Optional

from .routing import RouteResult
from .solver import Solution
from .term import bold, cyan, dim, green, pink

def banner() -> None:
    art = r"""
  _   _                      ____             _
 | \ | | _____  ___   _ ___|  _ \ ___  _   _| |_ ___
 |  \| |/ _ \ \/ / | | / __| |_) / _ \| | | | __/ _ \
 | |\  |  __/>  <| |_| \__ \  _ < (_) | |_| | ||  __/
 |_| \_|\___/_/\_\\__,_|___/_| \_\___/ \__,_|\__\___|   3.0  PYTHON EDITION
"""
    print(cyan(art))
    print(dim("  Advanced 3D Last-Mile Drone Delivery Optimizer  |  Knapsack DP + 2-opt + SA + Held-Karp + Repair\n"))


def _route_table(routes: Dict[str, RouteResult], best: Optional[RouteResult]) -> None:
    print(f"  {'Algorithm':<24}{'Distance':>10}{'On-time':>10}{'Lateness':>10}{'Cost':>10}{'ms':>9}")
    for r in routes.values():
        star = green(" <- best") if r is best else ""
        print(f"  {r.name:<24}{r.distance:>10.1f}{f'{r.n_on_time}/{len(r.stops)}':>10}"
              f"{r.total_lateness:>10.1f}{r.cost:>10.1f}{r.runtime_ms:>9.1f}{star}")


def print_report(sol: Solution) -> None:
    cfg, k = sol.cfg, sol.knap
    line = dim("-" * 90)
    print(bold(cyan(f"[ INSTANCE ]  seed={cfg.seed}  parcels={cfg.n_parcels}  capacity={cfg.capacity} kg  "
                    f"speed={cfg.speed}")))
    print(line)

    # ---- stage 1 --------------------------------------------------------------------------
    print(bold(cyan("[ STAGE 1 ]  0/1 KNAPSACK  (Dynamic Programming - maximises PAPER profit)")))
    print(f"  {'Parcel':<7}{'Profit':>8}{'Weight':>8}{'$/kg':>8}{'Deadline':>10}")
    for p in sol.dp_set:
        print(f"  {p.name:<7}{p.profit:>8}{p.weight:>8}{p.ratio:>8.2f}{p.deadline:>10}")
    gap_g = 100.0 * (k.profit - sol.greedy_profit) / sol.greedy_profit if sol.greedy_profit else 0.0
    print(f"  {green('Selected')} {len(sol.dp_set)}/{len(sol.parcels)} parcels | load "
          f"{k.weight}/{cfg.capacity} kg | {green('paper profit $' + str(k.profit))} (provably optimal)")
    print(f"  Greedy-by-ratio : ${sol.greedy_profit}  -> DP is {gap_g:+.2f}% better")
    print(f"  LP upper bound  : ${sol.lp_bound:.1f}  (optimum can never exceed this)  "
          f"integrality gap {100 * (sol.lp_bound - k.profit) / sol.lp_bound if sol.lp_bound else 0.0:.2f}%")
    print(dim(f"  DP table {k.table.shape[0]}x{k.table.shape[1]} filled in {k.runtime_ms:.2f} ms "
              f"-> O(n*W) = O({len(sol.parcels)}*{cfg.capacity})"))
    print(line)

    # ---- stage 2 --------------------------------------------------------------------------
    print(bold(cyan("[ STAGE 2 ]  ROUTING OF THE DP-OPTIMAL PARCELS")))
    _route_table(sol.dp_suite.routes, sol.dp_suite.best)
    b0, base = sol.dp_suite.best, sol.baseline
    print(f"  Realised profit (on-time only): original greedy ${base.realised_profit}  ->  "
          f"optimised routing ${b0.realised_profit}")
    print(line)

    # ---- stage 3 --------------------------------------------------------------------------
    rp = sol.repair
    print(bold(cyan("[ STAGE 3 ]  DEADLINE-AWARE REPAIR  (joint selection + routing)")))
    if not rp.enabled:
        print(dim("  disabled (--no-repair)"))
    elif not rp.moves:
        print(f"  {green('No improving move exists')} - the DP selection is already the best realised plan "
              f"({rp.evaluations} candidate sets tested in {rp.runtime_ms:.0f} ms).")
    else:
        for i, (desc, real) in enumerate(rp.moves, 1):
            print(f"  move {i}: {desc:<22} -> realised profit ${real}")
        print(f"  {green(f'Realised profit ${rp.start_realised} -> ${rp.final_realised}')}  "
              f"({rp.evaluations} candidate sets tested in {rp.runtime_ms:.0f} ms)  |  "
              f"paper profit ${k.profit} -> ${sol.final_profit}")
    print(line)
    print(bold(cyan(f"[ FINAL ROUTE OPTIMISATION ]  {len(sol.selected)} parcels, load {sol.final_weight}/{cfg.capacity} kg")))
    _route_table(sol.routes, sol.best)
    if sol.hk_distance is not None:
        extra = 100 * (sol.best.distance - sol.hk_distance) / max(sol.hk_distance, 1e-9)
        print(f"  {'Held-Karp (exact, LB)':<24}{sol.hk_distance:>10.1f}   "
              f"{dim(f'best route is {extra:+.1f}% vs the shortest possible tour (extra km buy punctuality)')}")
    else:
        print(dim("  Held-Karp skipped (too many selected parcels for exact search)."))
    print(line)

    # ---- itinerary ------------------------------------------------------------------------
    b = sol.best
    print(bold(cyan(f"[ MISSION ITINERARY ]  {b.name}")))
    print(f"  {'#':<4}{'Parcel':<8}{'ETA':>9}{'Deadline':>10}{'Slack':>9}   Status")
    print(f"  {'0':<4}{'HUB':<8}{0.0:>9.1f}")
    for i, (p, a, ok) in enumerate(zip(b.stops, b.arrivals, b.on_time), 1):
        slack = p.deadline - a
        st = green("ON TIME") if ok else pink(f"LATE by {-slack:.1f}")
        print(f"  {i:<4}{p.name:<8}{a:>9.1f}{p.deadline:>10}{slack:>9.1f}   {st}")
    print(f"  {'-':<4}{'HUB':<8}{b.distance / cfg.speed:>9.1f}   {dim('returned to base')}")
    print(line)
    gain = (f"{100 * (b.realised_profit - base.realised_profit) / base.realised_profit:+.0f}%"
            if base.realised_profit else "n/a")
    print(bold(green(f"[ RESULT ]  Realised profit ${b.realised_profit} vs original ${base.realised_profit} "
                     f"({gain})  |  On-time {b.n_on_time}/{len(b.stops)} ({b.efficiency:.1f}%) "
                     f"vs {base.n_on_time}/{len(base.stops)}")))
    print(dim(f"  Total compute time {sol.total_ms:.0f} ms\n"))


def export_results(sol: Solution, folder: str) -> None:
    out = Path(folder)
    out.mkdir(parents=True, exist_ok=True)
    b = sol.best
    report = {
        "config": {k: v for k, v in sol.cfg.__dict__.items()},
        "knapsack": {"profit": sol.knap.profit, "weight": sol.knap.weight,
                     "dp_selected_ids": [p.id for p in sol.dp_set],
                     "greedy_profit": sol.greedy_profit, "lp_upper_bound": sol.lp_bound},
        "repair": {"final_selected_ids": [p.id for p in sol.selected],
                   "moves": [m for m, _ in sol.repair.moves],
                   "realised_before": sol.repair.start_realised, "realised_after": sol.repair.final_realised},
        "routes": {n: {"distance": r.distance, "on_time": r.n_on_time, "stops": len(r.stops),
                       "lateness": r.total_lateness, "cost": r.cost, "runtime_ms": r.runtime_ms,
                       "order_ids": [p.id for p in r.stops]} for n, r in sol.routes.items()},
        "best_route": b.name,
        "held_karp_distance": sol.hk_distance,
    }
    (out / "report.json").write_text(json.dumps(report, indent=2))
    with open(out / "route.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["step", "parcel", "x", "y", "z", "profit", "weight", "eta", "deadline", "on_time"])
        for i, (p, a, ok) in enumerate(zip(b.stops, b.arrivals, b.on_time), 1):
            w.writerow([i, p.name, f"{p.x:.2f}", f"{p.y:.2f}", f"{p.z:.2f}", p.profit, p.weight,
                        f"{a:.2f}", p.deadline, ok])
    print(green(f"  Exported report.json and route.csv -> {out.resolve()}"))
