"""Tiny ANSI colour helpers for the terminal report (auto-disabled when output is piped)."""
from __future__ import annotations

import os
import sys

if os.name == "nt":
    os.system("")  # enables ANSI escape codes on Windows 10+ terminals


def _enabled() -> bool:
    return sys.stdout.isatty()


def _c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if _enabled() else s


def cyan(s): return _c("96", s)
def green(s): return _c("92", s)
def pink(s): return _c("91", s)
def yellow(s): return _c("93", s)
def dim(s): return _c("90", s)
def bold(s): return _c("1", s)
