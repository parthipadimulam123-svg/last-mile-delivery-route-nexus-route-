"""STAGE 1 - 0/1 Knapsack by Dynamic Programming (+ greedy and LP-bound benchmarks)."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np

@dataclass
class KnapsackResult:
    table: np.ndarray                  # dp[i][w], shape (n+1, W+1)
    selected: List[int]                # indices (into the parcel list) that are loaded
    profit: int
    weight: int
    path: List[Tuple[int, int]]        # (w, i) back-tracking cursor positions
    taken_cells: List[Tuple[int, int]]  # (w, i) cells where an item is taken
    runtime_ms: float


def knapsack_dp(profits: Sequence[int], weights: Sequence[int], W: int) -> KnapsackResult:
    """
    0/1 KNAPSACK by bottom-up Dynamic Programming.

        dp[i][w] = best profit using ONLY the first i parcels with capacity w
        dp[0][w] = 0
        dp[i][w] = dp[i-1][w]                                   if weight_i > w
                   max( dp[i-1][w],                             (skip parcel i)
                        dp[i-1][w - weight_i] + profit_i )      (take parcel i)

    Time O(n*W), memory O(n*W).  Keeping the whole table (instead of one row) lets us
    reconstruct the chosen set by walking backwards and also draw the table as a heat-map.
    """
    t0 = time.perf_counter()
    n = len(profits)
    dp = [[0] * (W + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        wi, pi = weights[i - 1], profits[i - 1]
        prev, cur = dp[i - 1], dp[i]
        for w in range(W + 1):
            best = prev[w]
            if wi <= w and prev[w - wi] + pi > best:
                best = prev[w - wi] + pi
            cur[w] = best

    # --- back-tracking: parcel i was taken iff dp[i][w] != dp[i-1][w] ---------------------
    selected: List[int] = []
    w = W
    path = [(w, n)]
    taken_cells: List[Tuple[int, int]] = []
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            selected.append(i - 1)
            taken_cells.append((w, i))
            w -= weights[i - 1]
        path.append((w, i - 1))
    selected.reverse()
    return KnapsackResult(
        table=np.array(dp, dtype=np.int64),
        selected=selected,
        profit=int(dp[n][W]),
        weight=W - w,
        path=path,
        taken_cells=taken_cells,
        runtime_ms=(time.perf_counter() - t0) * 1e3,
    )


def greedy_by_ratio(profits: Sequence[int], weights: Sequence[int], W: int) -> Tuple[int, List[int]]:
    """Classic heuristic: take parcels in decreasing profit/weight order while they fit."""
    order = sorted(range(len(profits)), key=lambda i: profits[i] / weights[i], reverse=True)
    left, total, chosen = W, 0, []
    for i in order:
        if weights[i] <= left:
            chosen.append(i)
            left -= weights[i]
            total += profits[i]
    return total, chosen


def fractional_upper_bound(profits: Sequence[int], weights: Sequence[int], W: int) -> float:
    """LP relaxation (parcels may be split).  Always >= the true integer optimum."""
    order = sorted(range(len(profits)), key=lambda i: profits[i] / weights[i], reverse=True)
    left, total = float(W), 0.0
    for i in order:
        if weights[i] <= left:
            left -= weights[i]
            total += profits[i]
        else:
            total += profits[i] * left / weights[i]
            break
    return total
