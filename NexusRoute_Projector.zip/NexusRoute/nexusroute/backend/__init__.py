"""BACKEND - pure algorithms (knapsack DP, routing, repair, solver).  Needs only NumPy."""
from .flight import Flight, build_flight
from .knapsack import KnapsackResult, fractional_upper_bound, greedy_by_ratio, knapsack_dp
from .models import Config, Parcel, generate_parcels
from .report import banner, export_results, print_report
from .routing import (RouteResult, RoutingProblem, held_karp, local_search,
                      nearest_neighbour_deadline_aware, simulated_annealing)
from .solver import ROUTE_LS, ROUTE_NN, ROUTE_SA, RepairInfo, RouteSuite, Solution, repair_selection, solve

__all__ = [n for n in dir() if not n.startswith("_")]
