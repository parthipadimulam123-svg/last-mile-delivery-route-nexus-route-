"""Pre-computed drone flight timeline (positions, payload, events) used by the animation."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from .solver import Solution

@dataclass
class Flight:
    pts: np.ndarray          # (F,3) drone position per frame
    t: np.ndarray            # mission time per frame
    leg: np.ndarray          # index of the stop being flown to (m = returning to hub)
    dwell_k: np.ndarray      # >=0 while dropping parcel k, else -1
    dwell_p: np.ndarray      # drop-off animation progress 0..1
    payload: np.ndarray      # kg still on board
    delivered: np.ndarray    # parcels delivered so far
    events: List[Tuple[int, str, str]]   # (frame, kind, message)
    total_time: float

    @property
    def n(self) -> int:
        return len(self.pts)


def build_flight(sol: Solution, frames_per_leg: int = 34, dwell: int = 9) -> Flight:
    route = sol.best
    m = len(route.stops)
    wps = [np.zeros(3)] + [p.pos for p in route.stops] + [np.zeros(3)]
    legs = len(wps) - 1
    avg = max(1.0, route.distance / max(1, legs))
    k = frames_per_leg / avg                    # frames per unit distance  => constant speed
    payload = sum(p.weight for p in route.stops)
    pts, ts, lg, dk, dpv, pay, dl = [], [], [], [], [], [], []
    events: List[Tuple[int, str, str]] = []

    def emit(pos, t, leg, kk, pp, pl, de):
        pts.append(np.asarray(pos, float)); ts.append(t); lg.append(leg)
        dk.append(kk); dpv.append(pp); pay.append(pl); dl.append(de)

    delivered, clock = 0, 0.0
    for _ in range(8):                                   # pre-flight hold
        emit(wps[0], 0.0, 0, -1, 0.0, payload, 0)
    for leg in range(legs):
        a, b = wps[leg], wps[leg + 1]
        d = float(np.linalg.norm(b - a))
        nfr = max(6, int(round(d * k)))
        for s in range(1, nfr + 1):
            u = s / nfr
            emit(a + (b - a) * u, clock + d * u / sol.cfg.speed, leg, -1, 0.0, payload, delivered)
        clock += d / sol.cfg.speed
        if leg < m:
            p = route.stops[leg]
            payload -= p.weight
            delivered += 1
            ok = route.on_time[leg]
            slack = route.deadlines[leg] - route.arrivals[leg]
            msg = (f"Arrived {p.name} [#{leg + 1}] ON TIME  ETA {route.arrivals[leg]:.0f}"
                   f" <= {route.deadlines[leg]}  (+{slack:.0f} slack)" if ok else
                   f"Arrived {p.name} [#{leg + 1}] LATE by {-slack:.1f}  ETA {route.arrivals[leg]:.0f}"
                   f" > {route.deadlines[leg]}")
            events.append((len(pts) - 1, "ok" if ok else "late", msg))
            for s in range(dwell):
                emit(b, clock, leg, leg, (s + 1) / dwell, payload, delivered)
        else:
            events.append((len(pts) - 1, "done",
                           f"Mission complete. Drone back at hub, T = {clock:.1f}."))
    for _ in range(26):                                  # post-flight hold
        emit(wps[-1], clock, m, -1, 0.0, payload, delivered)
    return Flight(np.array(pts), np.array(ts), np.array(lg), np.array(dk), np.array(dpv),
                  np.array(pay), np.array(dl), events, clock)
