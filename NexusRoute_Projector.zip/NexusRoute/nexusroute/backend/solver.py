"""STAGE 3 - deadline-aware repair + the full end-to-end solver pipeline."""
from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from .knapsack import KnapsackResult, fractional_upper_bound, greedy_by_ratio, knapsack_dp
from .models import Config, Parcel
from .routing import (RouteResult, RoutingProblem, held_karp, local_search,
                      nearest_neighbour_deadline_aware, simulated_annealing)

ROUTE_NN = "Greedy NN (baseline)"
ROUTE_LS = "2-opt + Or-opt"
ROUTE_SA = "Simulated Annealing"


@dataclass
class RouteSuite:
    """The three routing algorithms applied to one fixed set of parcels."""
    parcels: List[Parcel]
    routes: Dict[str, RouteResult]
    best: RouteResult


def route_suite(selected: Sequence[Parcel], cfg: Config, sa_iters: int) -> Tuple[RouteSuite, RoutingProblem]:
    prob = RoutingProblem(selected, cfg)
    t = time.perf_counter()
    nn = nearest_neighbour_deadline_aware(prob, cfg.nn_penalty)
    r_nn = prob.evaluate(ROUTE_NN, nn, (time.perf_counter() - t) * 1e3)
    t = time.perf_counter()
    ls = local_search(prob, nn)
    r_ls = prob.evaluate(ROUTE_LS, ls, (time.perf_counter() - t) * 1e3)
    t = time.perf_counter()
    rng = random.Random((cfg.seed or 0) + 7919)
    sa = simulated_annealing(prob, ls, rng, sa_iters)
    r_sa = prob.evaluate(ROUTE_SA, sa, (time.perf_counter() - t) * 1e3)
    routes = {ROUTE_NN: r_nn, ROUTE_LS: r_ls, ROUTE_SA: r_sa}
    # the winner is judged on what matters commercially: profit that really arrives on time,
    # ties are broken by the routing cost (distance + lateness penalties)
    best = min(routes.values(), key=lambda r: (-r.realised_profit, r.cost))
    return RouteSuite(list(selected), routes, best), prob


@dataclass
class RepairInfo:
    enabled: bool
    moves: List[Tuple[str, int]]     # (human readable move, realised profit after the move)
    start_realised: int
    final_realised: int
    evaluations: int
    runtime_ms: float


def repair_selection(cfg: Config, parcels: Sequence[Parcel], dp_idx: Sequence[int]
                     ) -> Tuple[List[int], RepairInfo]:
    """
    WHY THIS EXISTS
        The knapsack maximises *paper* profit and knows nothing about WHERE a parcel is or WHEN
        it is due.  A parcel delivered after its deadline earns nothing, so the real ("realised")
        profit of the DP-optimal load can be much lower than its paper profit.

    WHAT IT DOES
        Hill-climbing over the SET of loaded parcels, starting from the DP optimum, using three
        neighbourhood moves that keep the load <= capacity:
            ADD one parcel   |   DROP one parcel   |   SWAP one loaded for one unloaded parcel
        Every candidate set is scored by routing it (greedy NN and 2-opt/Or-opt) and measuring
        the profit of the parcels that arrive ON TIME.  Because the start state is the original
        plan and a move is only accepted if it strictly improves, the result can never be worse
        than the original pipeline (a guarantee verified by the self-test).  The best-improving move is applied until
        no move helps.  Scores are cached, so each distinct set is routed only once.
    """
    t0 = time.perf_counter()
    W = cfg.capacity
    cache: Dict[frozenset, Tuple[int, int, float]] = {}

    def score(S) -> Tuple[int, int, float]:
        key = frozenset(S)
        if key not in cache:
            prob = RoutingProblem([parcels[i] for i in sorted(S)], cfg)
            nn = nearest_neighbour_deadline_aware(prob, cfg.nn_penalty)
            paper = sum(parcels[i].profit for i in S)
            tuples = []
            for order in (nn, local_search(prob, nn)):          # judge the set by its better route
                r = prob.evaluate("q", order)
                tuples.append((r.realised_profit, paper, -r.distance))
            cache[key] = max(tuples)
        return cache[key]

    def better(a, b) -> bool:
        if a[0] != b[0]:
            return a[0] > b[0]
        if a[1] != b[1]:
            return a[1] > b[1]
        return a[2] > b[2] + 1e-6

    cur = set(dp_idx)
    cur_s = score(cur)
    start_real = cur_s[0]
    moves: List[Tuple[str, int]] = []
    if cfg.repair:
        load = lambda S: sum(parcels[i].weight for i in S)
        for _ in range(cfg.repair_sweeps):
            out = [i for i in range(len(parcels)) if i not in cur]
            w_now = load(cur)
            cands = []
            for j in out:
                if w_now + parcels[j].weight <= W:
                    cands.append((cur | {j}, f"ADD  {parcels[j].name}"))
            for i in cur:
                cands.append((cur - {i}, f"DROP {parcels[i].name}"))
            for i in cur:
                for j in out:
                    if w_now - parcels[i].weight + parcels[j].weight <= W:
                        cands.append(((cur - {i}) | {j}, f"SWAP {parcels[i].name} -> {parcels[j].name}"))
            best_c, best_s, best_d = None, cur_s, ""
            for c, d in cands:
                if time.perf_counter() - t0 > cfg.repair_budget_s:
                    break
                sc = score(c)
                if better(sc, best_s):
                    best_c, best_s, best_d = c, sc, d
            if best_c is None:
                break
            cur, cur_s = best_c, best_s
            moves.append((best_d, cur_s[0]))
            if time.perf_counter() - t0 > cfg.repair_budget_s:
                break
    info = RepairInfo(cfg.repair, moves, start_real, cur_s[0], len(cache), (time.perf_counter() - t0) * 1e3)
    return sorted(cur), info


@dataclass
class Solution:
    cfg: Config
    parcels: List[Parcel]
    knap: KnapsackResult              # STAGE 1 result (paper-optimal set)
    greedy_profit: int
    lp_bound: float
    dp_set: List[Parcel]              # parcels chosen by the DP
    selected: List[Parcel]            # parcels finally loaded (after repair)
    dropped: List[Parcel]             # DP picks removed by the repair
    added: List[Parcel]               # parcels brought in by the repair
    skipped: List[Parcel]             # never selected
    dp_suite: RouteSuite              # routing of the DP set   (original pipeline + improvements)
    suite: RouteSuite                 # routing of the final set
    repair: RepairInfo
    hk_distance: Optional[float]
    hk_order: Optional[List[int]]
    total_ms: float

    @property
    def routes(self) -> Dict[str, RouteResult]:
        return self.suite.routes

    @property
    def best(self) -> RouteResult:
        return self.suite.best

    @property
    def baseline(self) -> RouteResult:
        """The ORIGINAL v1 pipeline: DP-optimal set + greedy nearest-neighbour route."""
        return self.dp_suite.routes[ROUTE_NN]

    @property
    def final_profit(self) -> int:
        return sum(p.profit for p in self.selected)

    @property
    def final_weight(self) -> int:
        return sum(p.weight for p in self.selected)


def solve(cfg: Config, parcels: Sequence[Parcel], with_hk: bool = True) -> Solution:
    t_all = time.perf_counter()
    profits = [p.profit for p in parcels]
    weights = [p.weight for p in parcels]

    # STAGE 1 : knapsack ------------------------------------------------------------------------
    knap = knapsack_dp(profits, weights, cfg.capacity)
    greedy_profit, _ = greedy_by_ratio(profits, weights, cfg.capacity)
    lp = fractional_upper_bound(profits, weights, cfg.capacity)
    dp_set = [parcels[i] for i in knap.selected]

    # STAGE 2 : routing of the DP set -----------------------------------------------------------
    dp_suite, _ = route_suite(dp_set, cfg, max(500, cfg.sa_iters // 3))

    # STAGE 3 : deadline-aware repair of the selection, then full routing ---------------------
    final_idx, info = repair_selection(cfg, parcels, knap.selected)
    if set(final_idx) == set(knap.selected):
        suite, prob = route_suite(dp_set, cfg, cfg.sa_iters)
    else:
        suite, prob = route_suite([parcels[i] for i in final_idx], cfg, cfg.sa_iters)
    dp_ids, fin_ids = set(knap.selected), set(final_idx)
    selected = [parcels[i] for i in final_idx]
    dropped = [parcels[i] for i in sorted(dp_ids - fin_ids)]
    added = [parcels[i] for i in sorted(fin_ids - dp_ids)]
    skipped = [p for i, p in enumerate(parcels) if i not in dp_ids and i not in fin_ids]

    hk_d, hk_o = None, None
    if with_hk and 0 < prob.m <= cfg.hk_limit:
        hk_d, hk_o = held_karp(prob.D)

    return Solution(cfg, list(parcels), knap, greedy_profit, lp, dp_set, selected, dropped, added, skipped,
                    dp_suite, suite, info, hk_d, hk_o, (time.perf_counter() - t_all) * 1e3)
