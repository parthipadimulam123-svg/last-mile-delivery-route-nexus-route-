"""DATA MODEL - configuration, parcels and the random city generator (no GUI dependencies)."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import List, Optional

import numpy as np

@dataclass
class Config:
    """All tunable parameters of one experiment."""
    n_parcels: int = 30          # number of candidate parcels
    capacity: int = 60           # drone payload limit (kg)
    seed: Optional[int] = None   # random seed (None -> chosen at start-up and printed)
    area: float = 240.0          # city is a square of side `area` centred on the hub
    speed: float = 1.0           # distance units per time unit
    late_penalty: float = 60.0   # routing cost added per late parcel
    nn_penalty: float = 50.0     # penalty used by the ORIGINAL greedy heuristic
    sa_iters: int = 12000        # simulated-annealing iterations
    hk_limit: int = 13           # run exact Held-Karp only when #selected <= this
    repair: bool = True          # STAGE 3: deadline-aware repair of the knapsack selection
    repair_sweeps: int = 10      # max hill-climbing sweeps of the repair stage
    repair_budget_s: float = 2.0  # wall-clock cap for the repair stage (keeps the UI snappy)


@dataclass(frozen=True)
class Parcel:
    """One delivery request.  Coordinates: x, y horizontal, z = altitude."""
    id: int
    x: float
    y: float
    z: float
    profit: int
    weight: int
    deadline: int

    @property
    def pos(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z], dtype=float)

    @property
    def ratio(self) -> float:
        return self.profit / self.weight

    @property
    def name(self) -> str:
        return f"N{self.id:02d}"


def generate_parcels(cfg: Config) -> List[Parcel]:
    """Random city.  Ranges are identical to the original JavaScript version."""
    rng = random.Random(cfg.seed)
    half = cfg.area / 2.0
    parcels: List[Parcel] = []
    for i in range(1, cfg.n_parcels + 1):
        profit = rng.randint(15, 104)
        weight = rng.randint(4, 15)
        x = rng.uniform(-half, half)
        y = rng.uniform(-half, half)
        z = rng.uniform(-10.0, 20.0)
        dist_hub = math.sqrt(x * x + y * y + z * z)
        deadline = int(dist_hub * 0.8 + rng.random() * 60) + 40
        parcels.append(Parcel(i, x, y, z, profit, weight, deadline))
    return parcels
