"""Allows:  python -m nexusroute  [options]"""
import sys

from .cli import main

sys.exit(main())
