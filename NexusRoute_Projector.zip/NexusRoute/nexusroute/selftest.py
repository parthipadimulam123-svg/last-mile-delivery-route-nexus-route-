"""Automatic correctness tests: every algorithm is verified against brute force."""
from __future__ import annotations

import itertools
import random
from typing import List, Tuple

import numpy as np

from .backend.knapsack import fractional_upper_bound, greedy_by_ratio, knapsack_dp
from .backend.models import Config, generate_parcels
from .backend.report import banner
from .backend.routing import held_karp
from .backend.solver import ROUTE_LS, ROUTE_SA, solve
from .backend.term import bold, cyan, dim, green, pink


def run_selftest() -> int:
    banner()
    print(bold(cyan("[ SELF-TEST ]  verifying every algorithm against brute force\n")))
    results: List[Tuple[str, bool, str]] = []
    rng = random.Random(2024)

    def check(name: str, ok: bool, info: str = "") -> None:
        results.append((name, ok, info))
        print(f"  [{green(' PASS ') if ok else pink(' FAIL ')}] {name:<66}{dim(info)}")

    # 1. knapsack DP == brute force
    bad = 0
    for _ in range(150):
        n = rng.randint(1, 12); W = rng.randint(5, 60)
        pr = [rng.randint(1, 100) for _ in range(n)]; wt = [rng.randint(1, 20) for _ in range(n)]
        best = 0
        for mask in range(1 << n):
            w = sum(wt[i] for i in range(n) if mask >> i & 1)
            if w <= W:
                best = max(best, sum(pr[i] for i in range(n) if mask >> i & 1))
        r = knapsack_dp(pr, wt, W)
        sel_w = sum(wt[i] for i in r.selected); sel_p = sum(pr[i] for i in r.selected)
        if r.profit != best or sel_p != best or sel_w > W or sel_w != r.weight:
            bad += 1
    check("Knapsack DP equals brute-force optimum (150 random instances)", bad == 0, f"{bad} mismatches")

    # 2. bounds: greedy <= DP <= LP
    bad = 0
    for _ in range(300):
        n = rng.randint(5, 40); W = rng.randint(20, 100)
        pr = [rng.randint(1, 100) for _ in range(n)]; wt = [rng.randint(1, 20) for _ in range(n)]
        dp = knapsack_dp(pr, wt, W).profit; g, _ = greedy_by_ratio(pr, wt, W); lp = fractional_upper_bound(pr, wt, W)
        if not (g <= dp <= lp + 1e-9):
            bad += 1
    check("Ordering  greedy <= DP optimum <= LP upper bound (300 instances)", bad == 0, f"{bad} violations")

    # 3. Held-Karp == brute force over permutations
    bad = 0
    for _ in range(40):
        m = rng.randint(2, 7)
        pts = np.vstack([np.zeros(3)] + [np.array([rng.uniform(-50, 50) for _ in range(3)]) for _ in range(m)])
        D = np.linalg.norm(pts[:, None] - pts[None], axis=2)
        bf = min(D[0, p[0] + 1] + sum(D[p[i] + 1, p[i + 1] + 1] for i in range(m - 1)) + D[p[-1] + 1, 0]
                 for p in itertools.permutations(range(m)))
        hk, order = held_karp(D)
        rebuilt = D[0, order[0] + 1] + sum(D[order[i] + 1, order[i + 1] + 1] for i in range(m - 1)) + D[order[-1] + 1, 0]
        if abs(hk - bf) > 1e-6 or abs(rebuilt - hk) > 1e-6 or sorted(order) != list(range(m)):
            bad += 1
    check("Held-Karp equals brute-force shortest tour (40 instances, m<=7)", bad == 0, f"{bad} mismatches")

    # 4. routing validity + monotone improvement (always compared on the SAME parcel set)
    bad_perm = bad_mono = bad_hk = bad_cap = bad_rep = bad_v1 = 0
    for s in range(60):
        cfg = Config(n_parcels=30, capacity=60, seed=1000 + s, sa_iters=3000)
        sol = solve(cfg, generate_parcels(cfg))
        m = len(sol.selected)
        for suite in (sol.dp_suite, sol.suite):
            for r in suite.routes.values():
                if sorted(r.order) != list(range(len(suite.parcels))):
                    bad_perm += 1
            c_nn, c_ls, c_sa = (suite.routes[k].cost for k in suite.routes)
            if not (c_ls <= c_nn + 1e-6 and c_sa <= c_ls + 1e-6):
                bad_mono += 1
        if sol.hk_distance is not None and min(r.distance for r in sol.routes.values()) < sol.hk_distance - 1e-6:
            bad_hk += 1
        if sol.final_weight > cfg.capacity or sol.knap.weight > cfg.capacity:
            bad_cap += 1
        if sol.repair.final_realised < sol.repair.start_realised:
            bad_rep += 1
        if sol.best.realised_profit < sol.baseline.realised_profit:
            bad_v1 += 1
    check("Every route is a valid permutation of its parcel set", bad_perm == 0, f"{bad_perm} invalid")
    check("cost(SA) <= cost(2-opt/Or-opt) <= cost(greedy NN)  (60 cities)", bad_mono == 0, f"{bad_mono} violations")
    check("No heuristic route is shorter than the Held-Karp optimum", bad_hk == 0, f"{bad_hk} violations")
    check("Capacity is never exceeded (DP set and repaired set)", bad_cap == 0, f"{bad_cap} violations")
    check("Repair never lowers the realised (on-time) profit", bad_rep == 0, f"{bad_rep} violations")
    check("NexusRoute 3.0 is never worse than the original v1 pipeline", bad_v1 == 0, f"{bad_v1} violations")

    # 5. reproducibility
    c1 = Config(seed=77); c2 = Config(seed=77)
    s1 = solve(c1, generate_parcels(c1)); s2 = solve(c2, generate_parcels(c2))
    check("Same seed -> identical results (reproducible experiments)",
          s1.best.order == s2.best.order and s1.knap.profit == s2.knap.profit)

    # 6. edge cases
    try:
        c = Config(n_parcels=10, capacity=1, seed=5); sol = solve(c, generate_parcels(c))
        ok = (len(sol.selected) == 0 and sol.best.distance == 0.0)
    except Exception as exc:  # pragma: no cover
        ok = False
    check("Edge case: capacity too small -> empty route handled gracefully", ok)

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n  {bold(green(f'{passed}/{len(results)} tests passed')) if passed == len(results) else pink(f'{passed}/{len(results)} passed')}\n")
    return 0 if passed == len(results) else 1
