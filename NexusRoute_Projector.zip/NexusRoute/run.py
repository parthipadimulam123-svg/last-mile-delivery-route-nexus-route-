#!/usr/bin/env python3
"""NexusRoute 3.0 launcher:   python run.py   (see  python run.py --help)"""
import sys

from nexusroute.cli import main

if __name__ == "__main__":
    sys.exit(main())
